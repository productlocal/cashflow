export type TransactionType = 'income' | 'expense';

export type PaymentStage = 'dp1' | 'dp2' | 'dp3' | 'pelunasan' | 'manual_income' | 'expense';

export interface Transaction {
  id: string;
  type: TransactionType;
  stage: PaymentStage;
  category: string;
  amount: number;
  
  // Jamaah & Agent Information
  namaJamaah: string; // Nama jamaah sesuai passport
  nomorPassport?: string; // Nomor passport jamaah (opsional)
  namaAgent: string; // Nama agent / mitra perwakilan
  tanggalBerangkat: string; // Format: YYYY-MM-DD
  pindahTanggal?: string; // Format: YYYY-MM-DD (jika ada jadwal pindah tanggal)
  
  // Realtime & Manual Timing
  transactionDate: string; // ISO string / YYYY-MM-DDTHH:mm
  isManualDate: boolean;
  
  // Details & Notes
  keterangan: string; // Keterangan manual detail
  metodePembayaran?: string; // Transfer Bank Mandiri, BCA, BSI, Cash Tunai
  
  // PIC (Petugas yang mengerjakan)
  pic: string;
  picRole?: string;
  createdAt: string;
  updatedAt?: string;
  lastEditedByPic?: string;
}

export interface PicUser {
  id: string;
  username: string;
  nama: string;
  role: string;
  avatarColor: string;
  online: boolean;
  lastActive: string;
}

export type TaskPriority = 'urgent' | 'normal' | 'low';
export type TaskStatus = 'pending' | 'in_progress' | 'completed';

export interface TaskReply {
  id: string;
  senderPic: string; // PIC yang membalas (PIC 2, PIC 3, PIC 4, PIC 5, dll)
  senderRole?: string;
  text: string; // Teks balasan ke PIC 1
  createdAt: string;
}

export interface TaskNote {
  id: string;
  title: string; // Judul Perintah Penugasan (cth: "Tolong input cashflow jamaah Lintang")
  detail?: string; // Instruksi detail tambahan
  assignedByPic: string; // PIC yang memberi perintah penugasan (Hanya PIC 1 - Kiki yang berwenang)
  assignedToPic: string; // PIC yang ditugaskan (penerima tugas: PIC 2, Nabila, PIC 3, dll)
  priority: TaskPriority; // 'urgent' | 'normal' | 'low'
  status: TaskStatus; // 'pending' | 'in_progress' | 'completed'
  deadline?: string; // Target tanggal / batas penyelesaian
  createdAt: string;
  updatedAt?: string;
  completedAt?: string;
  transactionRefId?: string;
  transactionRefSummary?: string;
  replies?: TaskReply[]; // Balasan teks dari PIC penerima tugas yang tersampaikan ke PIC 1
}

export function isPicUtama(picNameOrUser?: string | PicUser | null): boolean {
  if (!picNameOrUser) return false;
  if (typeof picNameOrUser === 'string') {
    const s = picNameOrUser.toLowerCase();
    return s.includes('kiki') || s.includes('pic 1') || s.includes('utama');
  }
  const u = (picNameOrUser.username || '').toLowerCase();
  const n = (picNameOrUser.nama || '').toLowerCase();
  const r = (picNameOrUser.role || '').toLowerCase();
  return u === 'kiki' || n.includes('kiki') || n.includes('pic 1') || r.includes('utama');
}

export interface CashflowSummary {
  totalSaldo: number;
  totalIncome: number;
  totalExpense: number;
  totalJamaah: number;
  totalLunas: number;
  totalPendingDP: number;
}
