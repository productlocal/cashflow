import { Transaction, PicUser, TaskNote } from './types';

export const INITIAL_PICS: PicUser[] = [
  {
    id: 'pic-1',
    username: 'Kiki',
    nama: 'PIC 1 - Kiki',
    role: 'PIC 1 (Utama) - Koordinator & Pemberi Tugas',
    avatarColor: 'bg-emerald-600',
    online: true,
    lastActive: 'Baru saja'
  },
  {
    id: 'pic-2',
    username: 'Abil',
    nama: 'PIC 2 - Abil',
    role: 'Pendaftaran & Paspor Jamaah',
    avatarColor: 'bg-blue-600',
    online: true,
    lastActive: 'Baru saja'
  },
  {
    id: 'pic-nabila',
    username: 'Nabila',
    nama: 'Nabila',
    role: 'Lead Finance & Kasir',
    avatarColor: 'bg-indigo-600',
    online: true,
    lastActive: 'Baru saja'
  },
  {
    id: 'pic-3',
    username: 'PIC 3',
    nama: 'PIC 3 (Isi Manual)',
    role: 'Staff Operasional Umroh',
    avatarColor: 'bg-teal-600',
    online: true,
    lastActive: 'Baru saja'
  },
  {
    id: 'pic-4',
    username: 'PIC 4',
    nama: 'PIC 4 (Isi Manual)',
    role: 'Staff Operasional Umroh',
    avatarColor: 'bg-amber-600',
    online: false,
    lastActive: 'Baru saja'
  },
  {
    id: 'pic-5',
    username: 'PIC 5',
    nama: 'PIC 5 (Isi Manual)',
    role: 'Staff Operasional Umroh',
    avatarColor: 'bg-rose-600',
    online: false,
    lastActive: 'Baru saja'
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [];

export const INITIAL_TASKS: TaskNote[] = [
  {
    id: 'task-1',
    title: 'Tolong input cashflow jamaah Lintang (DP 1 Umroh)',
    detail: 'DP 1 transfer masuk via Bank BSI atas nama Lintang Pramesti, mohon diverifikasi dan dicatat di kas masuk.',
    assignedByPic: 'PIC 1 - Kiki',
    assignedToPic: 'Nabila',
    priority: 'urgent',
    status: 'pending',
    deadline: '2026-11-10',
    createdAt: new Date().toISOString(),
    replies: [
      {
        id: 'reply-1',
        senderPic: 'Nabila',
        senderRole: 'Lead Finance & Kasir',
        text: '(menerima) baik kak, segera saya input ke buku kas masuk.',
        createdAt: new Date().toISOString()
      }
    ]
  }
];

export const UMROH_CATEGORIES = {
  income: [
    'DP 1 Jamaah',
    'DP 2 Jamaah',
    'DP 3 Jamaah',
    'Pelunasan Jamaah',
    'Input Manual (Pemasukan)',
    'Investasi / Tambahan Modal',
    'Kelebihan Pembayaran / Kurs'
  ],
  expense: [
    'Tiket Pesawat',
    'Hotel Mekkah & Madinah',
    'Visa Umroh & Asuransi',
    'Transportasi (Bus / Kereta Cepat)',
    'Katering / Konsumsi',
    'Muthawif & Guide Lapangan',
    'Perlengkapan Umroh (Koper, dll)',
    'Fee / Komisi Agent & Mitra',
    'Operasional Kantor & Gaji',
    'Handling Bandara (CGK / JED / MED)',
    'Input Manual (Pengeluaran)'
  ]
};
