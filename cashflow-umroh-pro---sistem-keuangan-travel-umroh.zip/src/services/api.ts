import { Transaction, PicUser, TaskNote, TaskStatus } from '../types';
import { INITIAL_TRANSACTIONS, INITIAL_PICS, INITIAL_TASKS } from '../mockData';

const LOCAL_STORAGE_KEY_TRX = 'cashflow_umroh_trx';
const LOCAL_STORAGE_KEY_PICS = 'cashflow_umroh_pics';
const LOCAL_STORAGE_KEY_TASKS = 'cashflow_umroh_tasks';
const LOCAL_STORAGE_KEY_SESSION = 'cashflow_umroh_session';

// Initialize or refresh localStorage
function initLocalStore() {
  const versionKey = 'cashflow_umroh_version_v3';
  if (!localStorage.getItem(versionKey)) {
    localStorage.setItem(LOCAL_STORAGE_KEY_TRX, JSON.stringify([]));
    localStorage.setItem(LOCAL_STORAGE_KEY_PICS, JSON.stringify(INITIAL_PICS));
    localStorage.setItem(LOCAL_STORAGE_KEY_TASKS, JSON.stringify(INITIAL_TASKS));
    localStorage.setItem(versionKey, 'true');
  }
}
initLocalStore();

export async function loginUser(username: string, password: string, picName?: string): Promise<{ success: boolean; user?: PicUser; message?: string }> {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, picName })
    });
    if (res.ok) {
      const data = await res.json();
      const picUser: PicUser = {
        id: `pic-${data.user.nama}`,
        username: data.user.username,
        nama: data.user.nama,
        role: data.user.role || 'Staff Operasional Umroh',
        avatarColor: data.user.nama === 'Nabila' ? 'bg-emerald-600' : 'bg-blue-600',
        online: true,
        lastActive: 'Baru saja'
      };
      localStorage.setItem(LOCAL_STORAGE_KEY_SESSION, JSON.stringify(picUser));
      return { success: true, user: picUser };
    } else {
      const err = await res.json();
      return { success: false, message: err.message || 'Username atau Password salah' };
    }
  } catch (err) {
    // Local fallback check
    if (username.trim().toLowerCase() === 'kiki' && password === 'Ki88ki') {
      const picUser: PicUser = {
        id: 'pic-1',
        username: 'Kiki',
        nama: 'PIC 1 - Kiki',
        role: 'PIC 1 (Utama) - Koordinator & Pemberi Tugas',
        avatarColor: 'bg-emerald-600',
        online: true,
        lastActive: 'Baru saja'
      };
      localStorage.setItem(LOCAL_STORAGE_KEY_SESSION, JSON.stringify(picUser));
      return { success: true, user: picUser };
    } else if (username.trim().toLowerCase() === 'nabila' && password === 'Na88bila') {
      const picUser: PicUser = {
        id: 'pic-nabila',
        username: 'Nabila',
        nama: picName || 'Nabila',
        role: 'Lead Finance & Kasir',
        avatarColor: 'bg-blue-600',
        online: true,
        lastActive: 'Baru saja'
      };
      localStorage.setItem(LOCAL_STORAGE_KEY_SESSION, JSON.stringify(picUser));
      return { success: true, user: picUser };
    } else if (password === 'Ki88ki' || password === 'Na88bila') {
      const picUser: PicUser = {
        id: `pic-${Date.now()}`,
        username: username,
        nama: picName || username,
        role: 'Petugas PIC Travel',
        avatarColor: 'bg-indigo-600',
        online: true,
        lastActive: 'Baru saja'
      };
      localStorage.setItem(LOCAL_STORAGE_KEY_SESSION, JSON.stringify(picUser));
      return { success: true, user: picUser };
    }
    return { success: false, message: 'Username atau Password salah. (PIC 1 Utama: Kiki / Ki88ki)' };
  }
}

export function getCurrentUser(): PicUser | null {
  const session = localStorage.getItem(LOCAL_STORAGE_KEY_SESSION);
  if (!session) return null;
  try {
    return JSON.parse(session);
  } catch {
    return null;
  }
}

export function logoutUser(): void {
  localStorage.removeItem(LOCAL_STORAGE_KEY_SESSION);
}

// Fetch all transactions
export async function fetchTransactions(): Promise<Transaction[]> {
  try {
    const res = await fetch('/api/transactions');
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem(LOCAL_STORAGE_KEY_TRX, JSON.stringify(data));
      return data;
    }
  } catch (err) {
    console.warn('API error, using local storage fallback for transactions');
  }
  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TRX);
  return raw ? JSON.parse(raw) : INITIAL_TRANSACTIONS;
}

// Create new transaction
export async function createTransaction(data: Omit<Transaction, 'id' | 'createdAt'>): Promise<Transaction> {
  try {
    const res = await fetch('/api/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('API error, saving transaction locally');
  }

  // Fallback
  const newTrx: Transaction = {
    ...data,
    id: `trx-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    createdAt: new Date().toISOString()
  };
  const list = await fetchTransactions();
  list.unshift(newTrx);
  localStorage.setItem(LOCAL_STORAGE_KEY_TRX, JSON.stringify(list));
  return newTrx;
}

// Update transaction
export async function updateTransaction(id: string, updates: Partial<Transaction>, editorPic: string): Promise<Transaction> {
  try {
    const res = await fetch(`/api/transactions/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...updates, editorPic })
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('API error, updating transaction locally');
  }

  const list = await fetchTransactions();
  const index = list.findIndex(t => t.id === id);
  if (index !== -1) {
    list[index] = {
      ...list[index],
      ...updates,
      updatedAt: new Date().toISOString(),
      lastEditedByPic: editorPic
    };
    localStorage.setItem(LOCAL_STORAGE_KEY_TRX, JSON.stringify(list));
    return list[index];
  }
  throw new Error('Transaksi tidak ditemukan');
}

// Delete transaction
export async function deleteTransaction(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/transactions/${id}`, { method: 'DELETE' });
    if (res.ok) {
      return true;
    }
  } catch (err) {
    console.warn('API error, deleting transaction locally');
  }

  const list = await fetchTransactions();
  const filtered = list.filter(t => t.id !== id);
  localStorage.setItem(LOCAL_STORAGE_KEY_TRX, JSON.stringify(filtered));
  return true;
}

// Fetch PICs
export async function fetchPics(): Promise<PicUser[]> {
  try {
    const res = await fetch('/api/pics');
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem(LOCAL_STORAGE_KEY_PICS, JSON.stringify(data));
      return data;
    }
  } catch (err) {
    console.warn('API error, using local PICs');
  }
  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_PICS);
  return raw ? JSON.parse(raw) : INITIAL_PICS;
}

// Add or Register PIC
export async function registerPic(nama: string, role: string): Promise<PicUser> {
  try {
    const res = await fetch('/api/pics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nama, role })
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('API error, registering PIC locally');
  }

  const newPic: PicUser = {
    id: `pic-${Date.now()}`,
    username: nama.trim(),
    nama: nama.trim(),
    role: role || 'Staff Umroh',
    avatarColor: 'bg-emerald-600',
    online: true,
    lastActive: 'Baru saja'
  };
  const pics = await fetchPics();
  pics.push(newPic);
  localStorage.setItem(LOCAL_STORAGE_KEY_PICS, JSON.stringify(pics));
  return newPic;
}

// Update existing PIC (for PIC 3, 4, 5 isi manual)
export async function updatePicUser(id: string, nama: string, role?: string): Promise<PicUser> {
  try {
    const res = await fetch(`/api/pics/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nama, role })
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('API error, updating PIC locally');
  }

  const pics = await fetchPics();
  const index = pics.findIndex(p => p.id === id);
  if (index !== -1) {
    pics[index].nama = nama.trim();
    if (role) pics[index].role = role.trim();
    localStorage.setItem(LOCAL_STORAGE_KEY_PICS, JSON.stringify(pics));
    return pics[index];
  }
  throw new Error('PIC tidak ditemukan');
}

// --- Task Notes / Perintah Penugasan PIC ---

export interface TaskFilterParams {
  assignedTo?: string;
  assignedBy?: string;
  status?: string;
}

// Fetch all task notes
export async function fetchTaskNotes(params?: TaskFilterParams): Promise<TaskNote[]> {
  try {
    const query = new URLSearchParams();
    if (params?.assignedTo) query.append('assignedTo', params.assignedTo);
    if (params?.assignedBy) query.append('assignedBy', params.assignedBy);
    if (params?.status) query.append('status', params.status);

    const queryString = query.toString() ? `?${query.toString()}` : '';
    const res = await fetch(`/api/tasks${queryString}`);
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem(LOCAL_STORAGE_KEY_TASKS, JSON.stringify(data));
      return data;
    }
  } catch (err) {
    console.warn('API error, loading tasks from local storage');
  }

  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TASKS);
  let list: TaskNote[] = raw ? JSON.parse(raw) : INITIAL_TASKS;
  if (params?.assignedTo && params.assignedTo !== 'all') {
    list = list.filter(t => t.assignedToPic === params.assignedTo);
  }
  if (params?.assignedBy && params.assignedBy !== 'all') {
    list = list.filter(t => t.assignedByPic === params.assignedBy);
  }
  if (params?.status && params.status !== 'all') {
    list = list.filter(t => t.status === params.status);
  }
  return list;
}

// Create new task note
export async function createTaskNote(
  data: Omit<TaskNote, 'id' | 'createdAt' | 'status'>
): Promise<TaskNote> {
  try {
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('API error, saving task note locally');
  }

  const newTask: TaskNote = {
    ...data,
    id: `task-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TASKS);
  const all: TaskNote[] = raw ? JSON.parse(raw) : INITIAL_TASKS;
  all.unshift(newTask);
  localStorage.setItem(LOCAL_STORAGE_KEY_TASKS, JSON.stringify(all));
  return newTask;
}

// Update task note content
export async function updateTaskNote(
  id: string,
  updates: Partial<TaskNote>
): Promise<TaskNote> {
  try {
    const res = await fetch(`/api/tasks/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('API error, updating task note locally');
  }

  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TASKS);
  const all: TaskNote[] = raw ? JSON.parse(raw) : INITIAL_TASKS;
  const index = all.findIndex(t => t.id === id);
  if (index !== -1) {
    all[index] = {
      ...all[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    localStorage.setItem(LOCAL_STORAGE_KEY_TASKS, JSON.stringify(all));
    return all[index];
  }
  throw new Error('Catatan penugasan tidak ditemukan');
}

// Update task note status (pending / in_progress / completed)
export async function updateTaskStatus(
  id: string,
  status: TaskStatus
): Promise<TaskNote> {
  try {
    const res = await fetch(`/api/tasks/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (res.ok) {
      return await res.json();
    }
  } catch (err) {
    console.warn('API error, updating task status locally');
  }

  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TASKS);
  const all: TaskNote[] = raw ? JSON.parse(raw) : INITIAL_TASKS;
  const index = all.findIndex(t => t.id === id);
  if (index !== -1) {
    all[index].status = status;
    all[index].updatedAt = new Date().toISOString();
    if (status === 'completed') {
      all[index].completedAt = new Date().toISOString();
    } else {
      delete all[index].completedAt;
    }
    localStorage.setItem(LOCAL_STORAGE_KEY_TASKS, JSON.stringify(all));
    return all[index];
  }
  throw new Error('Catatan penugasan tidak ditemukan');
}

// Delete task note
export async function deleteTaskNote(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/tasks/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    if (res.ok) {
      return true;
    }
  } catch (err) {
    console.warn('API error, deleting task note locally');
  }

  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TASKS);
  const all: TaskNote[] = raw ? JSON.parse(raw) : INITIAL_TASKS;
  const filtered = all.filter(t => t.id !== id);
  localStorage.setItem(LOCAL_STORAGE_KEY_TASKS, JSON.stringify(filtered));
  return true;
}

// Add text reply from PIC 2, 3, 4, 5, etc. to PIC 1
export async function addTaskReply(
  taskId: string,
  text: string,
  senderPic: string,
  senderRole?: string
): Promise<TaskNote> {
  try {
    const res = await fetch(`/api/tasks/${encodeURIComponent(taskId)}/replies`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, senderPic, senderRole })
    });
    if (res.ok) {
      const data = await res.json();
      return data.task;
    }
  } catch (err) {
    console.warn('API error, saving reply locally');
  }

  const raw = localStorage.getItem(LOCAL_STORAGE_KEY_TASKS);
  const all: TaskNote[] = raw ? JSON.parse(raw) : INITIAL_TASKS;
  const index = all.findIndex(t => t.id === taskId);
  if (index !== -1) {
    if (!all[index].replies) all[index].replies = [];
    const reply = {
      id: `reply-${Date.now()}`,
      senderPic,
      senderRole,
      text: text.trim(),
      createdAt: new Date().toISOString()
    };
    all[index].replies!.push(reply);
    all[index].updatedAt = new Date().toISOString();
    localStorage.setItem(LOCAL_STORAGE_KEY_TASKS, JSON.stringify(all));
    return all[index];
  }
  throw new Error('Penugasan tidak ditemukan');
}

// Subscribe to Realtime SSE Events (Transactions & Tasks)
export function subscribeSseEvents(
  myPic: string,
  onTransactionEvent: (event: any) => void,
  onTaskEvent: (action: 'create' | 'update' | 'delete' | 'status', task: TaskNote) => void
): () => void {
  try {
    const eventSource = new EventSource(`/api/events?pic=${encodeURIComponent(myPic)}`);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'TRANSACTIONS_UPDATED') {
          onTransactionEvent(data);
        } else if (data.type === 'TASKS_UPDATED') {
          onTaskEvent(data.action, data.task);
        }
      } catch (e) {
        console.error('Error parsing SSE event:', e);
      }
    };

    return () => {
      eventSource.close();
    };
  } catch (e) {
    console.warn('SSE not supported or failed to connect:', e);
    return () => {};
  }
}
