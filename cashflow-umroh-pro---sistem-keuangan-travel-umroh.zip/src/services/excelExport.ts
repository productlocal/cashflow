import * as XLSX from 'xlsx';
import { Transaction } from '../types';

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function formatNumberOnly(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function exportDailyReportExcel(transactions: Transaction[], targetDate: string, currentPicName: string) {
  // Filter transactions for targetDate (YYYY-MM-DD)
  const filtered = transactions.filter(t => {
    const tDate = t.transactionDate.substring(0, 10);
    return tDate === targetDate;
  });

  // Calculate totals
  const totalIncome = filtered.reduce((sum, t) => t.type === 'income' ? sum + t.amount : sum, 0);
  const totalExpense = filtered.reduce((sum, t) => t.type === 'expense' ? sum + t.amount : sum, 0);
  const netBalance = totalIncome - totalExpense;

  const wb = XLSX.utils.book_new();

  // Sheet 1: Summary
  const summaryData = [
    ['LAPORAN KAS MASUK & KELUAR HARIAN (CASHFLOW UMROH)'],
    ['Tanggal Laporan', targetDate],
    ['Dicetak Oleh PIC', currentPicName],
    ['Waktu Cetak', new Date().toLocaleString('id-ID')],
    [''],
    ['RINGKASAN KEUANGAN HARI INI', 'NOMINAL (RUPIAH)'],
    ['Total Pemasukan (DP 1, 2, 3, Pelunasan, dll)', totalIncome],
    ['Total Pengeluaran (Tiket, Visa, Hotel, dll)', totalExpense],
    ['Surplus / Defisit Kas Harian', netBalance],
    ['Total Transaksi Terproses', filtered.length + ' Transaksi']
  ];

  const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
  wsSummary['!cols'] = [{ wch: 45 }, { wch: 25 }];
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Ringkasan Harian');

  // Sheet 2: Detail
  const detailRows = filtered.map((t, index) => ({
    'No': index + 1,
    'Waktu Transaksi': t.transactionDate ? new Date(t.transactionDate).toLocaleString('id-ID') : '-',
    'Tipe': t.type === 'income' ? 'Pemasukan' : 'Pengeluaran',
    'Tahap / Kategori': t.category,
    'Nama Jamaah Sesuai Passport': t.namaJamaah || '-',
    'Nomor Passport': t.nomorPassport || '-',
    'Nama Agent / Mitra': t.namaAgent || '-',
    'Tanggal Berangkat': t.tanggalBerangkat || '-',
    'Pindah ke Tanggal': t.pindahTanggal || '-',
    'Keterangan Manual': t.keterangan || '-',
    'Pemasukan (Rp)': t.type === 'income' ? t.amount : 0,
    'Pengeluaran (Rp)': t.type === 'expense' ? t.amount : 0,
    'Metode Bayar': t.metodePembayaran || '-',
    'PIC Petugas': t.pic
  }));

  // Add summary rows at bottom
  if (detailRows.length > 0) {
    detailRows.push({
      'No': '' as any,
      'Waktu Transaksi': '',
      'Tipe': '',
      'Tahap / Kategori': '',
      'Nama Jamaah Sesuai Passport': '',
      'Nomor Passport': '',
      'Nama Agent / Mitra': '',
      'Tanggal Berangkat': '',
      'Pindah ke Tanggal': '',
      'Keterangan Manual': 'TOTAL HARI INI',
      'Pemasukan (Rp)': totalIncome,
      'Pengeluaran (Rp)': totalExpense,
      'Metode Bayar': '',
      'PIC Petugas': ''
    });
    detailRows.push({
      'No': '' as any,
      'Waktu Transaksi': '',
      'Tipe': '',
      'Tahap / Kategori': '',
      'Nama Jamaah Sesuai Passport': '',
      'Nomor Passport': '',
      'Nama Agent / Mitra': '',
      'Tanggal Berangkat': '',
      'Pindah ke Tanggal': '',
      'Keterangan Manual': 'SISA SALDO KAS BERSIH',
      'Pemasukan (Rp)': netBalance,
      'Pengeluaran (Rp)': 0,
      'Metode Bayar': '',
      'PIC Petugas': ''
    });
  }

  const wsDetail = XLSX.utils.json_to_sheet(detailRows);
  wsDetail['!cols'] = [
    { wch: 6 },
    { wch: 20 },
    { wch: 14 },
    { wch: 22 },
    { wch: 30 },
    { wch: 16 },
    { wch: 25 },
    { wch: 16 },
    { wch: 16 },
    { wch: 40 },
    { wch: 18 },
    { wch: 18 },
    { wch: 20 },
    { wch: 18 }
  ];
  XLSX.utils.book_append_sheet(wb, wsDetail, 'Detail Transaksi Harian');

  const fileName = `Laporan_Cashflow_Umroh_Harian_${targetDate}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

export function exportMonthlyReportExcel(transactions: Transaction[], targetYearMonth: string, currentPicName: string) {
  // targetYearMonth format: 'YYYY-MM'
  const filtered = transactions.filter(t => {
    const tYearMonth = t.transactionDate.substring(0, 7);
    return tYearMonth === targetYearMonth;
  });

  const totalIncome = filtered.reduce((sum, t) => t.type === 'income' ? sum + t.amount : sum, 0);
  const totalExpense = filtered.reduce((sum, t) => t.type === 'expense' ? sum + t.amount : sum, 0);
  const netBalance = totalIncome - totalExpense;

  // Breakdown by category
  const categorySummary: Record<string, { count: number; total: number; type: string }> = {};
  filtered.forEach(t => {
    if (!categorySummary[t.category]) {
      categorySummary[t.category] = { count: 0, total: 0, type: t.type };
    }
    categorySummary[t.category].count += 1;
    categorySummary[t.category].total += t.amount;
  });

  const wb = XLSX.utils.book_new();

  // Sheet 1: Rekap Bulanan
  const summaryRows: any[][] = [
    ['LAPORAN ARUS KAS BULANAN TRAVEL UMROH (CASHFLOW UMROH PRO)'],
    ['Periode Bulan', targetYearMonth],
    ['PIC Penanggung Jawab', currentPicName],
    ['Tanggal Export', new Date().toLocaleString('id-ID')],
    [''],
    ['REKAPITULASI OMZET & BIAYA', 'JUMLAH (RUPIAH)'],
    ['Total Pemasukan (Omzet Kas Masuk)', totalIncome],
    ['Total Pengeluaran (Beban Operasional & LA)', totalExpense],
    ['Saldo Bersih / Laba Kas Bulanan', netBalance],
    ['Total Volume Transaksi', filtered.length + ' Transaksi'],
    [''],
    ['RINCIAN PER KATEGORI', 'TIPE', 'JUMLAH TRANSAKSI', 'TOTAL (RUPIAH)']
  ];

  Object.keys(categorySummary).forEach(cat => {
    const item = categorySummary[cat];
    summaryRows.push([
      cat,
      item.type === 'income' ? 'Pemasukan' : 'Pengeluaran',
      item.count,
      item.total
    ]);
  });

  const wsSummary = XLSX.utils.aoa_to_sheet(summaryRows);
  wsSummary['!cols'] = [{ wch: 38 }, { wch: 18 }, { wch: 20 }, { wch: 22 }];
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Rekapitulasi Bulanan');

  // Sheet 2: All transactions in month
  const sorted = [...filtered].sort((a, b) => new Date(a.transactionDate).getTime() - new Date(b.transactionDate).getTime());
  let runningBalance = 0;

  const detailRows = sorted.map((t, idx) => {
    if (t.type === 'income') {
      runningBalance += t.amount;
    } else {
      runningBalance -= t.amount;
    }
    return {
      'No': idx + 1,
      'Tanggal Transaksi': t.transactionDate ? new Date(t.transactionDate).toLocaleString('id-ID') : '-',
      'Tipe': t.type === 'income' ? 'Pemasukan' : 'Pengeluaran',
      'Kategori / Pos': t.category,
      'Nama Jamaah Sesuai Passport': t.namaJamaah || '-',
      'Nomor Passport': t.nomorPassport || '-',
      'Nama Agent / Mitra': t.namaAgent || '-',
      'Tgl Berangkat': t.tanggalBerangkat || '-',
      'Pindah ke Tanggal': t.pindahTanggal || '-',
      'Keterangan Detail': t.keterangan || '-',
      'Masuk (Rp)': t.type === 'income' ? t.amount : 0,
      'Keluar (Rp)': t.type === 'expense' ? t.amount : 0,
      'Saldo Kumulatif (Rp)': runningBalance,
      'Metode Bayar': t.metodePembayaran || '-',
      'PIC Input': t.pic
    };
  });

  if (detailRows.length > 0) {
    detailRows.push({
      'No': '' as any,
      'Tanggal Transaksi': '',
      'Tipe': '',
      'Kategori / Pos': '',
      'Nama Jamaah Sesuai Passport': '',
      'Nomor Passport': '',
      'Nama Agent / Mitra': '',
      'Tgl Berangkat': '',
      'Pindah ke Tanggal': '',
      'Keterangan Detail': 'TOTAL AKHIR BULAN',
      'Masuk (Rp)': totalIncome,
      'Keluar (Rp)': totalExpense,
      'Saldo Kumulatif (Rp)': netBalance,
      'Metode Bayar': '',
      'PIC Input': ''
    });
  }

  const wsDetail = XLSX.utils.json_to_sheet(detailRows);
  wsDetail['!cols'] = [
    { wch: 6 },
    { wch: 20 },
    { wch: 14 },
    { wch: 24 },
    { wch: 30 },
    { wch: 16 },
    { wch: 25 },
    { wch: 16 },
    { wch: 16 },
    { wch: 40 },
    { wch: 18 },
    { wch: 18 },
    { wch: 20 },
    { wch: 18 },
    { wch: 18 }
  ];
  XLSX.utils.book_append_sheet(wb, wsDetail, 'Buku Kas Bulanan');

  const fileName = `Laporan_Cashflow_Umroh_Bulanan_${targetYearMonth}.xlsx`;
  XLSX.writeFile(wb, fileName);
}
