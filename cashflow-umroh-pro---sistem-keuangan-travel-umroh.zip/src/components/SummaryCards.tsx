import React from 'react';
import { Wallet, ArrowDownRight, ArrowUpRight, Users, CheckCircle, Clock } from 'lucide-react';
import { Transaction } from '../types';
import { formatRupiah } from '../services/excelExport';

interface SummaryCardsProps {
  transactions: Transaction[];
  onQuickFilter: (filter: string) => void;
  activeFilter: string;
}

export default function SummaryCards({ transactions, onQuickFilter, activeFilter }: SummaryCardsProps) {
  const totalIncome = transactions.reduce((acc, t) => t.type === 'income' ? acc + t.amount : acc, 0);
  const totalExpense = transactions.reduce((acc, t) => t.type === 'expense' ? acc + t.amount : acc, 0);
  const totalSaldo = totalIncome - totalExpense;

  // Jamaah statistics
  const jamaahNames = new Set(
    transactions
      .filter(t => t.type === 'income' && t.namaJamaah && t.namaJamaah !== '-')
      .map(t => t.namaJamaah.trim().toUpperCase())
  );
  const lunasCount = transactions.filter(t => t.stage === 'pelunasan').length;
  const dpCount = transactions.filter(t => t.stage === 'dp1' || t.stage === 'dp2' || t.stage === 'dp3').length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      
      {/* Saldo Kas Tersedia */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs transition hover:border-slate-300">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Saldo Kas Tersedia
          </span>
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
            <Wallet className="w-4 h-4" />
          </div>
        </div>
        <div className="text-2xl font-bold text-slate-900 tracking-tight font-mono-numbers">
          {formatRupiah(totalSaldo)}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500">
          <span className="font-medium text-emerald-700">Arus Kas Real-Time</span>
          <span>·</span>
          <span>Update otomatis</span>
        </div>
      </div>

      {/* Total Pemasukan (DP 1, 2, 3 & Pelunasan) */}
      <div 
        onClick={() => onQuickFilter('income')}
        className={`bg-white border rounded-xl p-5 shadow-xs transition cursor-pointer ${
          activeFilter === 'income' ? 'border-emerald-500 ring-2 ring-emerald-500/10' : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Kas Masuk
          </span>
          <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
            <ArrowDownRight className="w-4 h-4" />
          </div>
        </div>
        <div className="text-2xl font-bold text-emerald-700 tracking-tight font-mono-numbers">
          +{formatRupiah(totalIncome)}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500">
          <span>DP 1, 2, 3 & Pelunasan Jamaah</span>
        </div>
      </div>

      {/* Total Pengeluaran */}
      <div 
        onClick={() => onQuickFilter('expense')}
        className={`bg-white border rounded-xl p-5 shadow-xs transition cursor-pointer ${
          activeFilter === 'expense' ? 'border-rose-500 ring-2 ring-rose-500/10' : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Kas Keluar
          </span>
          <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-700 flex items-center justify-center border border-rose-100">
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>
        <div className="text-2xl font-bold text-rose-700 tracking-tight font-mono-numbers">
          -{formatRupiah(totalExpense)}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500">
          <span>Tiket, Visa, Hotel & Operasional</span>
        </div>
      </div>

      {/* Total Jamaah Terdaftar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs transition hover:border-slate-300">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Jamaah Terdata
          </span>
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-100">
            <Users className="w-4 h-4" />
          </div>
        </div>
        <div className="text-2xl font-bold text-slate-900 tracking-tight font-mono-numbers">
          {jamaahNames.size} <span className="text-sm font-normal text-slate-500">Orang</span>
        </div>
        <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
          <span className="flex items-center gap-1 text-emerald-700 font-medium">
            <CheckCircle className="w-3 h-3" /> {lunasCount} Lunas
          </span>
          <span>·</span>
          <span className="flex items-center gap-1 text-amber-700 font-medium">
            <Clock className="w-3 h-3" /> {dpCount} Angsuran DP
          </span>
        </div>
      </div>

    </div>
  );
}
