import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Minus, 
  FileSpreadsheet, 
  LogOut, 
  Users, 
  Clock, 
  ChevronDown,
  UserCheck,
  Edit2,
  X,
  Check,
  Crown
} from 'lucide-react';
import { PicUser, isPicUtama } from '../types';

interface HeaderProps {
  currentPic: PicUser;
  availablePics: PicUser[];
  onSwitchPic: (pic: PicUser) => void;
  onLogout: () => void;
  onOpenTransactionModal: (type: 'income' | 'expense', stage?: string) => void;
  onOpenExcelModal: () => void;
  onUpdatePicName?: (picId: string, newName: string) => Promise<void>;
}

export default function Header({
  currentPic,
  availablePics,
  onSwitchPic,
  onLogout,
  onOpenTransactionModal,
  onOpenExcelModal,
  onUpdatePicName
}: HeaderProps) {
  const [currentDateTime, setCurrentDateTime] = useState('');
  const [showPicDropdown, setShowPicDropdown] = useState(false);
  const [editingPic, setEditingPic] = useState<PicUser | null>(null);
  const [tempPicName, setTempPicName] = useState('');

  // Live Realtime Clock (Indonesian Time)
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        weekday: 'long',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      };
      const formatted = new Intl.DateTimeFormat('id-ID', options).format(now);
      setCurrentDateTime(`${formatted} WIB`);
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 bg-emerald-600 text-white rounded-lg flex items-center justify-center shadow-sm">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7v10l10 5 10-5V7L12 2zm0 2.236l7.64 3.82-7.64 3.82-7.64-3.82L12 4.236zM4 8.764l7 3.5v7.472l-7-3.5V8.764zm9 10.972v-7.472l7-3.5v7.472l-7 3.5z" />
            </svg>
          </div>
          <div>
            <div className="font-bold text-slate-900 tracking-tight text-base leading-none">
              Cashflow Umroh Pro
            </div>
            <div className="text-[11px] text-slate-500 font-medium tracking-normal mt-0.5">
              Sistem Keuangan & Kas Travel
            </div>
          </div>
        </div>

        {/* Real-time Clock Zone */}
        <div className="hidden md:flex items-center gap-2 text-xs font-medium text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200/70">
          <Clock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span className="font-mono-numbers">{currentDateTime || 'Memuat waktu...'}</span>
        </div>

        {/* Right Actions & PIC Profile */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Quick Action Buttons */}
          <div className="hidden lg:flex items-center gap-2">
            <button
              onClick={() => onOpenTransactionModal('income', 'dp1')}
              className="px-3 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-lg transition flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ DP / Pemasukan</span>
            </button>
            <button
              onClick={() => onOpenTransactionModal('expense')}
              className="px-3 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200/80 rounded-lg transition flex items-center gap-1.5 whitespace-nowrap"
            >
              <Minus className="w-3.5 h-3.5" />
              <span>- Pengeluaran</span>
            </button>
          </div>

          {/* Excel Export Button */}
          <button
            onClick={onOpenExcelModal}
            className="px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition flex items-center gap-1.5 shadow-xs whitespace-nowrap"
            title="Download Laporan Harian & Bulanan Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="hidden sm:inline">Laporan Excel</span>
          </button>

          {/* Active PIC Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowPicDropdown(!showPicDropdown)}
              className="flex items-center gap-2 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition"
            >
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[11px] font-bold">
                {currentPic.nama.substring(0, 2).toUpperCase()}
              </div>
              <div className="text-left hidden sm:block max-w-[130px]">
                <div className="font-semibold text-slate-900 truncate leading-tight flex items-center gap-1">
                  <span>{currentPic.nama}</span>
                  {isPicUtama(currentPic) && <Crown className="w-3 h-3 text-amber-500 fill-amber-400 shrink-0" />}
                </div>
                <div className="text-[10px] text-slate-500 truncate leading-none">
                  {isPicUtama(currentPic) ? 'PIC 1 (Utama)' : 'PIC Petugas'}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Dropdown Menu */}
            {showPicDropdown && (
              <div 
                className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-lg p-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                onMouseLeave={() => setShowPicDropdown(false)}
              >
                <div className="px-3 py-2 border-b border-slate-100 mb-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Ganti Petugas (Multi-PIC)
                  </span>
                  <div className="text-xs text-slate-600 mt-0.5">
                    Aktif sebagai: <strong className="text-slate-900">{currentPic.nama}</strong>
                  </div>
                </div>

                <div className="space-y-0.5 max-h-56 overflow-y-auto">
                  {availablePics.map((pic) => (
                    <div
                      key={pic.id}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 text-xs rounded-lg transition ${
                        currentPic.nama === pic.nama
                          ? 'bg-emerald-50 text-emerald-900 font-semibold'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSwitchPic(pic);
                          setShowPicDropdown(false);
                        }}
                        className="flex-1 flex items-center gap-2 truncate text-left"
                      >
                        <div className={`w-5 h-5 rounded-full ${pic.avatarColor} text-white flex items-center justify-center text-[10px] font-bold shrink-0`}>
                          {pic.nama.substring(0, 1)}
                        </div>
                        <div className="truncate">
                          <div className="truncate font-medium">{pic.nama}</div>
                          <div className="text-[10px] text-slate-400 truncate">{pic.role}</div>
                        </div>
                      </button>

                      <div className="flex items-center gap-1 shrink-0 ml-1">
                        {currentPic.nama === pic.nama && (
                          <UserCheck className="w-3.5 h-3.5 text-emerald-600 mr-1" />
                        )}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingPic(pic);
                            setTempPicName(pic.nama);
                            setShowPicDropdown(false);
                          }}
                          className="p-1 text-slate-400 hover:text-emerald-700 hover:bg-slate-200/60 rounded"
                          title={`Ubah Nama ${pic.nama}`}
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-slate-100 mt-1 pt-1">
                  <button
                    onClick={() => {
                      setShowPicDropdown(false);
                      onLogout();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-lg transition text-left"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Keluar Sistem (Logout)</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Logout Button */}
          <button
            onClick={onLogout}
            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
            title="Keluar (Logout)"
          >
            <LogOut className="w-4 h-4" />
          </button>

        </div>

      </div>

      {/* Modal Ubah Nama PIC (Isi Manual) */}
      {editingPic && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white border border-slate-200 rounded-2xl shadow-xl p-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-slate-900">Ubah Nama Petugas (PIC)</h4>
              <button
                type="button"
                onClick={() => setEditingPic(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              Isi manual nama petugas untuk <strong>{editingPic.username}</strong>
            </p>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (!tempPicName.trim()) return;
                if (onUpdatePicName) {
                  await onUpdatePicName(editingPic.id, tempPicName.trim());
                }
                setEditingPic(null);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Nama PIC Baru
                </label>
                <input
                  type="text"
                  required
                  value={tempPicName}
                  onChange={(e) => setTempPicName(e.target.value)}
                  placeholder="Cth: PIC 3 - Farhan"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
                />
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setEditingPic(null)}
                  className="flex-1 py-1.5 text-xs font-semibold text-slate-600 border border-slate-200 rounded-lg hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center justify-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Simpan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
}
