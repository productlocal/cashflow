import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  ArrowDownRight, 
  ArrowUpRight, 
  Calendar, 
  PlaneTakeoff, 
  User, 
  Building2, 
  CheckCircle2, 
  Clock, 
  UserCheck, 
  X,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { Transaction, PicUser, isPicUtama } from '../types';
import { formatRupiah } from '../services/excelExport';

interface TransactionTableProps {
  transactions: Transaction[];
  onEdit: (transaction: Transaction) => void;
  onDelete: (id: string) => Promise<void>;
  currentPic: PicUser;
  availablePics: PicUser[];
  onAssignTask?: (picName: string, refTrx?: Transaction) => void;
}

export default function TransactionTable({
  transactions,
  onEdit,
  onDelete,
  currentPic,
  availablePics,
  onAssignTask
}: TransactionTableProps) {
  // Search state specifically prioritizing "nama jamaah sesuai passport"
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense' | 'dp' | 'pelunasan'>('all');
  const [filterPic, setFilterPic] = useState<string>('all');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Filter logic
  const filteredTransactions = useMemo(() => {
    const seenIds = new Set<string>();
    return transactions.filter(t => {
      // Prevent duplicate keys
      if (!t.id || seenIds.has(t.id)) return false;
      seenIds.add(t.id);

      // 1. Search query: checks namaJamaah (sesuai passport), passport number, agent, or keterangan
      if (searchQuery.trim()) {
        const query = searchQuery.trim().toLowerCase();
        const matchJamaah = (t.namaJamaah || '').toLowerCase().includes(query);
        const matchPassport = (t.nomorPassport || '').toLowerCase().includes(query);
        const matchAgent = (t.namaAgent || '').toLowerCase().includes(query);
        const matchDesc = (t.keterangan || '').toLowerCase().includes(query);
        if (!matchJamaah && !matchPassport && !matchAgent && !matchDesc) {
          return false;
        }
      }

      // 2. Filter Type
      if (filterType === 'income' && t.type !== 'income') return false;
      if (filterType === 'expense' && t.type !== 'expense') return false;
      if (filterType === 'dp' && !['dp1', 'dp2', 'dp3'].includes(t.stage)) return false;
      if (filterType === 'pelunasan' && t.stage !== 'pelunasan') return false;

      // 3. Filter PIC
      if (filterPic !== 'all' && t.pic !== filterPic) return false;

      return true;
    });
  }, [transactions, searchQuery, filterType, filterPic]);

  const handleDeleteExecute = async () => {
    if (!deleteConfirmId) return;
    setIsDeleting(true);
    try {
      await onDelete(deleteConfirmId);
      setDeleteConfirmId(null);
    } catch (e) {
      console.error('Delete failed:', e);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
      
      {/* Table Controls Bar: Passport Search & Filter Tabs */}
      <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between bg-white">
        
        {/* Prominent Search Bar: Nama Jamaah Sesuai Passport */}
        <div className="relative flex-1 max-w-lg">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari Nama Jamaah Sesuai Passport, Agen, atau Keterangan..."
            className="w-full pl-10 pr-9 py-2 text-sm bg-slate-50 hover:bg-white focus:bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition text-slate-900 placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Segmented Filter Buttons */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs font-medium">
            <button
              onClick={() => setFilterType('all')}
              className={`px-2.5 py-1 rounded-md transition ${
                filterType === 'all'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Semua ({transactions.length})
            </button>
            <button
              onClick={() => setFilterType('dp')}
              className={`px-2.5 py-1 rounded-md transition ${
                filterType === 'dp'
                  ? 'bg-white text-emerald-800 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              DP 1, 2, 3
            </button>
            <button
              onClick={() => setFilterType('pelunasan')}
              className={`px-2.5 py-1 rounded-md transition ${
                filterType === 'pelunasan'
                  ? 'bg-white text-emerald-800 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Pelunasan
            </button>
            <button
              onClick={() => setFilterType('expense')}
              className={`px-2.5 py-1 rounded-md transition ${
                filterType === 'expense'
                  ? 'bg-white text-rose-800 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Pengeluaran
            </button>
          </div>

          {/* Filter By PIC */}
          <select
            value={filterPic}
            onChange={(e) => setFilterPic(e.target.value)}
            className="px-2.5 py-1.5 text-xs font-medium bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
          >
            <option value="all">Semua PIC</option>
            {availablePics.map((pic) => (
              <option key={pic.id} value={pic.nama}>
                PIC: {pic.nama}
              </option>
            ))}
          </select>

        </div>

      </div>

      {/* Active Search / Filter Feedback */}
      {(searchQuery || filterType !== 'all' || filterPic !== 'all') && (
        <div className="px-4 py-2 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span>Menampilkan <strong>{filteredTransactions.length}</strong> transaksi</span>
            {searchQuery && (
              <span>untuk pencarian passport/jamaah: <strong className="text-emerald-700">"{searchQuery}"</strong></span>
            )}
            {filterPic !== 'all' && (
              <span>oleh PIC: <strong className="text-slate-800">{filterPic}</strong></span>
            )}
          </div>
          <button
            onClick={() => {
              setSearchQuery('');
              setFilterType('all');
              setFilterPic('all');
            }}
            className="text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Filter</span>
          </button>
        </div>
      )}

      {/* Table Body */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200/80 text-slate-500 font-semibold uppercase tracking-wider">
              <th className="py-3 px-4 w-36 whitespace-nowrap">Waktu Transaksi</th>
              <th className="py-3 px-4 min-w-[220px]">Nama Jamaah / Passport</th>
              <th className="py-3 px-4 min-w-[160px]">Agen / Jadwal Berangkat</th>
              <th className="py-3 px-4 w-40">Pos / Kategori</th>
              <th className="py-3 px-4 text-right w-36 whitespace-nowrap">Nominal (Rp)</th>
              <th className="py-3 px-4 w-32 whitespace-nowrap">PIC Petugas</th>
              <th className="py-3 px-4 text-right w-24 whitespace-nowrap">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredTransactions.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 px-4 text-center text-slate-400">
                  <div className="max-w-sm mx-auto">
                    <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-2">
                      <Search className="w-5 h-5 text-slate-400" />
                    </div>
                    <p className="font-semibold text-slate-700 text-sm">
                      {transactions.length === 0 ? 'Buku Kas Umroh Masih Bersih / Kosong' : 'Tidak ada data transaksi yang cocok'}
                    </p>
                    <p className="text-slate-400 text-xs mt-1">
                      {transactions.length === 0 
                        ? 'Mulai pencatatan dengan klik tombol "+ Input Kas Masuk" (DP 1, DP 2, DP 3, Pelunasan) di atas.'
                        : 'Coba ubah kata kunci pencarian nama jamaah passport atau reset filter.'}
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredTransactions.map((trx) => {
                const isIncome = trx.type === 'income';
                const formattedDate = trx.transactionDate
                  ? new Date(trx.transactionDate).toLocaleString('id-ID', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })
                  : '-';

                return (
                  <tr key={trx.id} className="hover:bg-slate-50/80 transition-colors group">
                    
                    {/* Waktu Transaksi */}
                    <td className="py-3.5 px-4 text-slate-500 font-mono-numbers whitespace-nowrap align-top">
                      <div className="font-medium text-slate-700">{formattedDate}</div>
                      {trx.isManualDate && (
                        <span className="text-[10px] text-amber-700 font-medium">Input Manual</span>
                      )}
                    </td>

                    {/* Nama Jamaah Sesuai Passport & Keterangan */}
                    <td className="py-3.5 px-4 align-top">
                      {trx.namaJamaah ? (
                        <div>
                          <div className="font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                            <span>{trx.namaJamaah}</span>
                            {trx.nomorPassport && trx.nomorPassport !== '-' && (
                              <span className="text-[10px] font-mono font-medium text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                                {trx.nomorPassport}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2 leading-relaxed">
                            {trx.keterangan}
                          </p>
                        </div>
                      ) : (
                        <div>
                          <div className="font-semibold text-slate-800">{trx.category}</div>
                          <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                            {trx.keterangan}
                          </p>
                        </div>
                      )}
                    </td>

                    {/* Agen & Tanggal Berangkat (Dengan status pindah tanggal) */}
                    <td className="py-3.5 px-4 align-top text-slate-600">
                      <div className="font-medium text-slate-800 truncate max-w-[180px]">
                        {trx.namaAgent || '-'}
                      </div>
                      
                      {trx.tanggalBerangkat && (
                        <div className="mt-1 flex items-center gap-1 text-[11px] text-slate-500">
                          <PlaneTakeoff className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>Brgkt: {new Date(trx.tanggalBerangkat).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                        </div>
                      )}

                      {trx.pindahTanggal && (
                        <div className="mt-0.5 flex items-center gap-1 text-[11px] text-amber-700 font-medium">
                          <span>&rarr; Pindah ke: {new Date(trx.pindahTanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                        </div>
                      )}
                    </td>

                    {/* Pos / Kategori (No pill slop, clean subtle styling) */}
                    <td className="py-3.5 px-4 align-top whitespace-nowrap">
                      <div className="font-semibold text-slate-900">{trx.category}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{trx.metodePembayaran || 'BSI'}</div>
                    </td>

                    {/* Nominal */}
                    <td className="py-3.5 px-4 text-right align-top whitespace-nowrap font-mono-numbers">
                      <div className={`text-sm font-bold ${isIncome ? 'text-emerald-700' : 'text-rose-700'}`}>
                        {isIncome ? '+' : '-'} {formatRupiah(trx.amount)}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5 uppercase tracking-wide">
                        {isIncome ? 'Kas Masuk' : 'Kas Keluar'}
                      </div>
                    </td>

                    {/* PIC Petugas */}
                    <td className="py-3.5 px-4 align-top whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-[10px] font-bold">
                          {(trx.pic || 'P').substring(0, 1).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-800 text-xs">{trx.pic || 'Petugas'}</div>
                          {onAssignTask && (
                            <button
                              type="button"
                              onClick={() => onAssignTask(trx.pic, trx)}
                              className="text-[10px] text-emerald-700 hover:text-emerald-800 font-semibold block mt-0.5 hover:underline"
                              title={isPicUtama(currentPic) ? "Beri perintah penugasan terkait transaksi ini" : "Buka note penugasan & kirim balasan"}
                            >
                              {isPicUtama(currentPic) ? '+ Beri Tugas' : 'Note Tugas'}
                            </button>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Actions: Edit & Hapus */}
                    <td className="py-3.5 px-4 text-right align-top whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => onEdit(trx)}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                          title="Edit Transaksi"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(trx.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                          title="Hapus Transaksi"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>

                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Clean Delete Confirmation Modal (NO window.confirm!) */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white border border-slate-200 rounded-2xl shadow-xl p-5 text-center animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3 border border-rose-100">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900">Hapus Transaksi Ini?</h4>
            <p className="text-xs text-slate-500 mt-1 mb-5">
              Data transaksi akan dihapus dari buku kas cashflow. Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                disabled={isDeleting}
                className="flex-1 py-2 px-3 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteExecute}
                disabled={isDeleting}
                className="flex-1 py-2 px-3 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition"
              >
                {isDeleting ? 'Menghapus...' : 'Ya, Hapus'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
