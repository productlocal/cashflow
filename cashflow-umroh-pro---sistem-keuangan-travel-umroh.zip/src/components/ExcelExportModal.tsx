import React, { useState } from 'react';
import { X, FileSpreadsheet, Calendar, Download, CheckCircle2 } from 'lucide-react';
import { Transaction, PicUser } from '../types';
import { exportDailyReportExcel, exportMonthlyReportExcel, formatRupiah } from '../services/excelExport';

interface ExcelExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  currentPic: PicUser;
}

export default function ExcelExportModal({
  isOpen,
  onClose,
  transactions,
  currentPic
}: ExcelExportModalProps) {
  const [activeTab, setActiveTab] = useState<'daily' | 'monthly'>('daily');
  
  // Daily target (YYYY-MM-DD)
  const todayStr = new Date().toISOString().slice(0, 10);
  const [targetDate, setTargetDate] = useState(todayStr);

  // Monthly target (YYYY-MM)
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const [targetMonth, setTargetMonth] = useState(currentMonthStr);

  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  // Filter count previews
  const dailyTrx = transactions.filter(t => (t.transactionDate || '').slice(0, 10) === targetDate);
  const dailyIncome = dailyTrx.reduce((sum, t) => t.type === 'income' ? sum + t.amount : sum, 0);
  const dailyExpense = dailyTrx.reduce((sum, t) => t.type === 'expense' ? sum + t.amount : sum, 0);

  const monthlyTrx = transactions.filter(t => (t.transactionDate || '').slice(0, 7) === targetMonth);
  const monthlyIncome = monthlyTrx.reduce((sum, t) => t.type === 'income' ? sum + t.amount : sum, 0);
  const monthlyExpense = monthlyTrx.reduce((sum, t) => t.type === 'expense' ? sum + t.amount : sum, 0);

  const handleExportDaily = () => {
    exportDailyReportExcel(transactions, targetDate, currentPic.nama);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  const handleExportMonthly = () => {
    exportMonthlyReportExcel(transactions, targetMonth, currentPic.nama);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Download Laporan Excel (XLSX)</h3>
              <p className="text-xs text-slate-500">Pilih periode laporan harian atau rekap bulanan</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="p-6 pb-2">
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setActiveTab('daily')}
              className={`py-2 px-3 text-xs font-semibold rounded-lg transition ${
                activeTab === 'daily'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Laporan Harian (Daily)
            </button>
            <button
              onClick={() => setActiveTab('monthly')}
              className={`py-2 px-3 text-xs font-semibold rounded-lg transition ${
                activeTab === 'monthly'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Laporan Bulanan (Monthly)
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-6 pt-2 space-y-4">
          
          {downloadSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>File Excel berhasil diunduh ke perangkat Anda!</span>
            </div>
          )}

          {activeTab === 'daily' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Pilih Tanggal Laporan
                </label>
                <input
                  type="date"
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
                />
              </div>

              {/* Data Preview */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5">
                <div className="flex justify-between text-slate-500">
                  <span>Jumlah Transaksi:</span>
                  <strong className="text-slate-800">{dailyTrx.length} Transaksi</strong>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Kas Masuk:</span>
                  <strong className="text-emerald-700 font-mono-numbers">+{formatRupiah(dailyIncome)}</strong>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Kas Keluar:</span>
                  <strong className="text-rose-700 font-mono-numbers">-{formatRupiah(dailyExpense)}</strong>
                </div>
                <div className="pt-1.5 border-t border-slate-200 flex justify-between font-bold text-slate-900">
                  <span>Saldo Bersih Harian:</span>
                  <span className="font-mono-numbers text-emerald-800">{formatRupiah(dailyIncome - dailyExpense)}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleExportDaily}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Laporan Harian ({targetDate})</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Pilih Bulan & Tahun Laporan
                </label>
                <input
                  type="month"
                  value={targetMonth}
                  onChange={(e) => setTargetMonth(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
                />
              </div>

              {/* Data Preview */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5">
                <div className="flex justify-between text-slate-500">
                  <span>Volume Transaksi Bulan Ini:</span>
                  <strong className="text-slate-800">{monthlyTrx.length} Transaksi</strong>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Omzet Masuk:</span>
                  <strong className="text-emerald-700 font-mono-numbers">+{formatRupiah(monthlyIncome)}</strong>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Beban Keluar:</span>
                  <strong className="text-rose-700 font-mono-numbers">-{formatRupiah(monthlyExpense)}</strong>
                </div>
                <div className="pt-1.5 border-t border-slate-200 flex justify-between font-bold text-slate-900">
                  <span>Laba Bersih Kas Bulanan:</span>
                  <span className="font-mono-numbers text-emerald-800">{formatRupiah(monthlyIncome - monthlyExpense)}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleExportMonthly}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-xs"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Rekap Bulanan ({targetMonth})</span>
              </button>
            </div>
          )}

          <p className="text-center text-[11px] text-slate-400">
            Format file .XLSX kompatibel dengan Microsoft Excel, Google Sheets, dan LibreOffice.
          </p>

        </div>

      </div>
    </div>
  );
}
