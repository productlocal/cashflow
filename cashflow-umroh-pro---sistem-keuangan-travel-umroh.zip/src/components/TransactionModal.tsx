import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  User, 
  UserCheck, 
  Building2, 
  CalendarDays, 
  PlaneTakeoff, 
  CalendarClock, 
  FileText, 
  Check, 
  AlertCircle 
} from 'lucide-react';
import { Transaction, PaymentStage, PicUser } from '../types';
import { UMROH_CATEGORIES } from '../mockData';
import { formatNumberOnly } from '../services/excelExport';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Transaction, 'id' | 'createdAt'>) => Promise<void>;
  initialData?: Transaction | null;
  defaultType?: 'income' | 'expense';
  defaultStage?: string;
  currentPic: PicUser;
  availablePics: PicUser[];
}

export default function TransactionModal({
  isOpen,
  onClose,
  onSave,
  initialData,
  defaultType = 'income',
  defaultStage = 'dp1',
  currentPic,
  availablePics
}: TransactionModalProps) {
  const [type, setType] = useState<'income' | 'expense'>(defaultType);
  const [stage, setStage] = useState<PaymentStage>('dp1');
  const [category, setCategory] = useState<string>('DP 1 Jamaah');
  const [amountRaw, setAmountRaw] = useState<string>('');
  
  // Specific required fields
  const [namaJamaah, setNamaJamaah] = useState('');
  const [nomorPassport, setNomorPassport] = useState('');
  const [namaAgent, setNamaAgent] = useState('');
  const [tanggalBerangkat, setTanggalBerangkat] = useState('');
  const [pindahTanggal, setPindahTanggal] = useState('');
  const [hasPindahTanggal, setHasPindahTanggal] = useState(false);
  
  // Realtime vs Manual Timing
  const [isManualDate, setIsManualDate] = useState(false);
  const [transactionDateTime, setTransactionDateTime] = useState('');
  
  // Details
  const [keterangan, setKeterangan] = useState('');
  const [metodePembayaran, setMetodePembayaran] = useState('Transfer Bank BSI');
  
  // PIC
  const [picName, setPicName] = useState(currentPic.nama);
  
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Helper to get local ISO string YYYY-MM-DDTHH:mm
  const getNowLocal = () => {
    const now = new Date();
    const offset = now.getTimezoneOffset() * 60000;
    return new Date(now.getTime() - offset).toISOString().slice(0, 16);
  };

  useEffect(() => {
    if (initialData) {
      setType(initialData.type);
      setStage(initialData.stage);
      setCategory(initialData.category);
      setAmountRaw(initialData.amount ? String(initialData.amount) : '');
      setNamaJamaah(initialData.namaJamaah || '');
      setNomorPassport(initialData.nomorPassport || '');
      setNamaAgent(initialData.namaAgent || '');
      setTanggalBerangkat(initialData.tanggalBerangkat || '');
      setPindahTanggal(initialData.pindahTanggal || '');
      setHasPindahTanggal(!!initialData.pindahTanggal);
      setIsManualDate(!!initialData.isManualDate);
      setTransactionDateTime(initialData.transactionDate ? initialData.transactionDate.slice(0, 16) : getNowLocal());
      setKeterangan(initialData.keterangan || '');
      setMetodePembayaran(initialData.metodePembayaran || 'Transfer Bank BSI');
      setPicName(initialData.pic || currentPic.nama);
    } else {
      setType(defaultType);
      const initStage = (defaultStage as PaymentStage) || (defaultType === 'income' ? 'dp1' : 'expense');
      setStage(initStage);
      if (defaultType === 'income') {
        if (initStage === 'dp1') setCategory('DP 1 Jamaah');
        else if (initStage === 'dp2') setCategory('DP 2 Jamaah');
        else if (initStage === 'dp3') setCategory('DP 3 Jamaah');
        else if (initStage === 'pelunasan') setCategory('Pelunasan Jamaah');
        else setCategory('Input Manual (Pemasukan)');
      } else {
        setCategory('Tiket Pesawat');
      }
      setAmountRaw('');
      setNamaJamaah('');
      setNomorPassport('');
      setNamaAgent('');
      setTanggalBerangkat('');
      setPindahTanggal('');
      setHasPindahTanggal(false);
      setIsManualDate(false);
      setTransactionDateTime(getNowLocal());
      setKeterangan('');
      setMetodePembayaran('Transfer Bank BSI');
      setPicName(currentPic.nama);
    }
    setErrorMsg('');
  }, [isOpen, initialData, defaultType, defaultStage, currentPic]);

  if (!isOpen) return null;

  // Handle stage shortcuts
  const selectStage = (selectedStage: PaymentStage) => {
    setStage(selectedStage);
    if (selectedStage === 'dp1') {
      setType('income');
      setCategory('DP 1 Jamaah');
    } else if (selectedStage === 'dp2') {
      setType('income');
      setCategory('DP 2 Jamaah');
    } else if (selectedStage === 'dp3') {
      setType('income');
      setCategory('DP 3 Jamaah');
    } else if (selectedStage === 'pelunasan') {
      setType('income');
      setCategory('Pelunasan Jamaah');
    } else if (selectedStage === 'manual_income') {
      setType('income');
      setCategory('Input Manual (Pemasukan)');
    } else if (selectedStage === 'expense') {
      setType('expense');
      setCategory('Tiket Pesawat');
    }
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value.replace(/[^0-9]/g, '');
    setAmountRaw(rawVal);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amountRaw, 10);
    if (!numAmount || numAmount <= 0) {
      setErrorMsg('Nominal transaksi harus lebih dari 0.');
      return;
    }

    if (type === 'income' && !namaJamaah.trim()) {
      setErrorMsg('Nama jamaah sesuai passport wajib diisi untuk pencatatan pembayaran.');
      return;
    }

    setSaving(true);
    setErrorMsg('');

    try {
      const selectedPicObj = availablePics.find(p => p.nama === picName);
      await onSave({
        type,
        stage,
        category,
        amount: numAmount,
        namaJamaah: namaJamaah.trim(),
        nomorPassport: nomorPassport.trim(),
        namaAgent: namaAgent.trim(),
        tanggalBerangkat,
        pindahTanggal: hasPindahTanggal ? pindahTanggal : '',
        transactionDate: isManualDate ? transactionDateTime : getNowLocal(),
        isManualDate,
        keterangan: keterangan.trim(),
        metodePembayaran,
        pic: picName,
        picRole: selectedPicObj?.role || 'Staff Travel Umroh'
      });
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal menyimpan transaksi.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {initialData ? 'Edit Data Transaksi Umroh' : (type === 'income' ? 'Input Kas Masuk Jamaah' : 'Input Kas Keluar Umroh')}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Alur Input: Jamaah &rarr; Agen &rarr; Tgl Berangkat &rarr; Pindah Tgl &rarr; DP 1, 2, 3 / Pelunasan
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[82vh] overflow-y-auto">
          
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Quick Flow Stage Selector: DP 1 > DP 2 > DP 3 > Pelunasan > Input Manual > Pengeluaran */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Tahapan Pembayaran / Pos Keuangan
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              <button
                type="button"
                onClick={() => selectStage('dp1')}
                className={`py-2 px-2 text-xs font-semibold rounded-lg border transition text-center ${
                  stage === 'dp1'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                DP 1
              </button>
              <button
                type="button"
                onClick={() => selectStage('dp2')}
                className={`py-2 px-2 text-xs font-semibold rounded-lg border transition text-center ${
                  stage === 'dp2'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                DP 2
              </button>
              <button
                type="button"
                onClick={() => selectStage('dp3')}
                className={`py-2 px-2 text-xs font-semibold rounded-lg border transition text-center ${
                  stage === 'dp3'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                DP 3
              </button>
              <button
                type="button"
                onClick={() => selectStage('pelunasan')}
                className={`py-2 px-2 text-xs font-semibold rounded-lg border transition text-center ${
                  stage === 'pelunasan'
                    ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Pelunasan
              </button>
              <button
                type="button"
                onClick={() => selectStage('manual_income')}
                className={`py-2 px-2 text-xs font-semibold rounded-lg border transition text-center ${
                  stage === 'manual_income'
                    ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Manual In
              </button>
              <button
                type="button"
                onClick={() => selectStage('expense')}
                className={`py-2 px-2 text-xs font-semibold rounded-lg border transition text-center ${
                  stage === 'expense'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Pengeluaran
              </button>
            </div>
          </div>

          {/* 1. Nama Jamaah & Nomor Passport */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Nama Jamaah Sesuai Passport {type === 'income' && <span className="text-rose-500">*</span>}
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required={type === 'income'}
                  value={namaJamaah}
                  onChange={(e) => setNamaJamaah(e.target.value.toUpperCase())}
                  placeholder="Cth: BUDI SANTOSO"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 uppercase font-medium text-slate-900"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Nomor Passport <span className="text-[11px] font-normal text-slate-400">(Opsional)</span>
              </label>
              <input
                type="text"
                value={nomorPassport}
                onChange={(e) => setNomorPassport(e.target.value.toUpperCase())}
                placeholder="Cth: B1298471"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 uppercase text-slate-900 font-mono"
              />
            </div>
          </div>

          {/* 2. Nama Agent / Mitra */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Nama Agent / Mitra Perwakilan
            </label>
            <div className="relative">
              <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={namaAgent}
                onChange={(e) => setNamaAgent(e.target.value)}
                placeholder="Cth: Mitra Berkah Mandiri / KBIHU Al-Ihsan / Direct Jamaah"
                className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
              />
            </div>
          </div>

          {/* 3. Tanggal Berangkat & Pindah ke Tanggal */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50/70 p-3.5 rounded-xl border border-slate-200/80">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <PlaneTakeoff className="w-3.5 h-3.5 text-emerald-600" />
                Tanggal Berangkat
              </label>
              <input
                type="date"
                value={tanggalBerangkat}
                onChange={(e) => setTanggalBerangkat(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <CalendarClock className="w-3.5 h-3.5 text-amber-600" />
                  Pindah ke Tanggal
                </label>
                <label className="flex items-center gap-1 text-[11px] text-slate-500 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasPindahTanggal}
                    onChange={(e) => setHasPindahTanggal(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Ada Pindah Jadwal?</span>
                </label>
              </div>

              {hasPindahTanggal ? (
                <input
                  type="date"
                  value={pindahTanggal}
                  onChange={(e) => setPindahTanggal(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-amber-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 text-slate-900"
                />
              ) : (
                <div className="text-xs text-slate-400 py-2.5 px-3 bg-white/50 border border-dashed border-slate-200 rounded-lg">
                  Tidak ada perubahan tanggal berangkat
                </div>
              )}
            </div>
          </div>

          {/* 4. Kategori Spesifik & Nominal */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Kategori Transaksi *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900 font-medium"
              >
                {type === 'income' ? (
                  UMROH_CATEGORIES.income.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))
                ) : (
                  UMROH_CATEGORIES.expense.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))
                )}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Nominal Transaksi (Rp) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                  Rp
                </span>
                <input
                  type="text"
                  required
                  value={amountRaw ? formatNumberOnly(parseInt(amountRaw, 10)) : ''}
                  onChange={handleAmountChange}
                  placeholder="0"
                  className={`w-full pl-9 pr-3 py-2 text-base font-bold bg-white border rounded-lg focus:outline-none focus:ring-2 font-mono-numbers ${
                    type === 'income'
                      ? 'border-emerald-300 text-emerald-800 focus:border-emerald-600 focus:ring-emerald-500/20'
                      : 'border-rose-300 text-rose-800 focus:border-rose-600 focus:ring-rose-500/20'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* 5. Metode Bayar & PIC Petugas */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Metode Pembayaran
              </label>
              <select
                value={metodePembayaran}
                onChange={(e) => setMetodePembayaran(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
              >
                <option value="Transfer Bank BSI">Transfer Bank BSI</option>
                <option value="Transfer Bank Mandiri">Transfer Bank Mandiri</option>
                <option value="Transfer Bank BCA">Transfer Bank BCA</option>
                <option value="Transfer Bank BRI">Transfer Bank BRI</option>
                <option value="Cash / Tunai">Cash / Tunai di Kantor</option>
                <option value="Swift Transfer SAR (Saudi)">Swift Transfer SAR (Saudi)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1 flex items-center justify-between">
                <span>Nama PIC yang Mengerjakan *</span>
              </label>
              <div className="relative">
                <UserCheck className="w-4 h-4 text-emerald-600 absolute left-3 top-1/2 -translate-y-1/2" />
                <select
                  value={picName}
                  onChange={(e) => setPicName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900 font-semibold"
                >
                  {availablePics.map(pic => (
                    <option key={pic.id} value={pic.nama}>
                      {pic.nama} ({pic.role})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* 6. Tanggal dan Waktu Realtime (Bisa Input Manual) */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                Tanggal & Waktu Transaksi
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsManualDate(false)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${
                    !isManualDate
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Realtime (Sekarang)
                </button>
                <button
                  type="button"
                  onClick={() => setIsManualDate(true)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition ${
                    isManualDate
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Input Manual
                </button>
              </div>
            </div>

            {isManualDate ? (
              <input
                type="datetime-local"
                value={transactionDateTime}
                onChange={(e) => setTransactionDateTime(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
              />
            ) : (
              <div className="text-xs text-slate-600 flex items-center gap-2 py-1 font-mono-numbers">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Otomatis tercatat pada waktu nyata: {new Date().toLocaleString('id-ID')}</span>
              </div>
            )}
          </div>

          {/* 7. Keterangan Detail (Input Manual) */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Keterangan Detail (Input Manual) *
            </label>
            <textarea
              required
              rows={2}
              value={keterangan}
              onChange={(e) => setKeterangan(e.target.value)}
              placeholder="Contoh: Pembayaran DP 1 untuk 2 pax paket Umroh Reguler 12 Hari Quad Room..."
              className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900 resize-none"
            />
          </div>

          {/* Modal Action Buttons */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
              className="flex-1 py-2.5 px-4 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-sm rounded-xl transition"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={saving}
              className={`flex-1 py-2.5 px-4 text-white font-semibold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-xs ${
                type === 'income'
                  ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800'
                  : 'bg-rose-600 hover:bg-rose-700 active:bg-rose-800'
              }`}
            >
              {saving ? (
                <span>Menyimpan Transaksi...</span>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>{initialData ? 'Perbarui Transaksi' : 'Simpan Transaksi'}</span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
