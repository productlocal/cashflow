import React, { useState } from 'react';
import { Lock, User, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import { PicUser } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  onLoginSuccess: (user: PicUser) => void;
  availablePics: PicUser[];
}

export default function LoginModal({ isOpen, onLoginSuccess, availablePics }: LoginModalProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    const trimmedUser = username.trim();
    const targetPicName = trimmedUser.toLowerCase() === 'kiki' ? 'PIC 1 - Kiki' : trimmedUser;

    // Strict credential check based on user prompt:
    // Pic 1 (utama) yg bisa memberikan perintah penugasan ke Pic 2 dll 
    // Username : Kiki
    // Password : Ki88ki
    const isValidKiki = trimmedUser.toLowerCase() === 'kiki' && password === 'Ki88ki';
    const isValidNabila = trimmedUser.toLowerCase() === 'nabila' && password === 'Na88bila';
    const isValidStaff = (password === 'Ki88ki' || password === 'Na88bila') && trimmedUser.length > 0;

    if (!isValidKiki && !isValidNabila && !isValidStaff) {
      setErrorMsg('Username atau Password salah. (PIC 1 Utama -> Username: Kiki, Password: Ki88ki)');
      setLoading(false);
      return;
    }

    try {
      const { loginUser } = await import('../services/api');
      const res = await loginUser(username.trim(), password, targetPicName);
      if (res.success && res.user) {
        onLoginSuccess(res.user);
      } else {
        setErrorMsg(res.message || 'Gagal login, periksa username dan password.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Terjadi kesalahan sistem.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header - Clean & Minimalist */}
        <div className="p-8 pb-4 text-center">
          <div className="inline-flex items-center justify-center w-14 h-14 bg-emerald-50 text-emerald-700 rounded-xl mb-3 border border-emerald-100 shadow-sm">
            <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7v10l10 5 10-5V7L12 2zm0 2.236l7.64 3.82-7.64 3.82-7.64-3.82L12 4.236zM4 8.764l7 3.5v7.472l-7-3.5V8.764zm9 10.972v-7.472l7-3.5v7.472l-7 3.5z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-900">Cashflow Umroh Pro</h2>
          <p className="text-sm text-slate-500 mt-1">Sistem Keuangan & Arus Kas Travel Umroh</p>
        </div>

        {/* Form - Bersih Tanpa Banner & Tanpa Pilihan PIC */}
        <form onSubmit={handleSubmit} className="p-8 pt-2 space-y-4">
          
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Username
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Masukkan username..."
                autoComplete="username"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition text-slate-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Masukkan password..."
                autoComplete="current-password"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition text-slate-900 font-mono"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold rounded-xl transition duration-150 shadow-sm flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <span>Memverifikasi...</span>
              ) : (
                <>
                  <span>Masuk ke Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
