import React, { useState, useMemo } from 'react';
import { 
  X, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Clock, 
  AlertCircle, 
  Trash2, 
  Edit3, 
  User, 
  Send, 
  Calendar, 
  Filter, 
  Check, 
  FileText,
  AlertTriangle,
  ArrowRight,
  MessageCircle,
  ShieldAlert,
  Crown
} from 'lucide-react';
import { TaskNote, PicUser, TaskPriority, TaskStatus, Transaction, isPicUtama } from '../types';

interface TaskNoteDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentPic: PicUser;
  availablePics: PicUser[];
  tasks: TaskNote[];
  onCreateTask: (data: Omit<TaskNote, 'id' | 'createdAt' | 'status'>) => Promise<void>;
  onUpdateTask: (id: string, updates: Partial<TaskNote>) => Promise<void>;
  onToggleStatus: (id: string, newStatus: TaskStatus) => Promise<void>;
  onDeleteTask: (id: string) => Promise<void>;
  onAddReply: (taskId: string, text: string, senderPic: string, senderRole?: string) => Promise<void>;
  initialRefTrx?: Transaction | null;
}

export default function TaskNoteDrawer({
  isOpen,
  onClose,
  currentPic,
  availablePics,
  tasks,
  onCreateTask,
  onUpdateTask,
  onToggleStatus,
  onDeleteTask,
  onAddReply,
  initialRefTrx
}: TaskNoteDrawerProps) {
  // Check if current logged-in PIC is PIC 1 (Utama)
  const isUtama = isPicUtama(currentPic);

  // Navigation tabs: 'list' | 'create'
  // If not PIC 1, always default to 'list' because only PIC 1 can issue new assignment orders
  const [activeTab, setActiveTab] = useState<'list' | 'create'>('list');
  
  // Filter for list
  const [filterScope, setFilterScope] = useState<'all' | 'to_me' | 'by_me' | 'pending' | 'completed'>('all');

  // Form State for creating / editing task (PIC 1 only)
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDetail, setTaskDetail] = useState('');
  const [assignedToPic, setAssignedToPic] = useState<string>('PIC 2 - Abil');
  const [priority, setPriority] = useState<TaskPriority>('urgent');
  const [deadline, setDeadline] = useState<string>('');
  const [refTrxSummary, setRefTrxSummary] = useState<string>('');
  const [refTrxId, setRefTrxId] = useState<string>('');

  // Per-task reply draft inputs (keyed by task.id)
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [replyingTaskId, setReplyingTaskId] = useState<string | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // If opened with prefilled transaction context
  React.useEffect(() => {
    if (initialRefTrx && isUtama) {
      setActiveTab('create');
      setTaskTitle(`Input & Verifikasi Kas: ${initialRefTrx.namaJamaah || initialRefTrx.category}`);
      setTaskDetail(`Mohon cek transaksi ${initialRefTrx.category} senilai Rp ${initialRefTrx.amount.toLocaleString('id-ID')} untuk jamaah ${initialRefTrx.namaJamaah || '-'}.`);
      setRefTrxSummary(`${initialRefTrx.namaJamaah || initialRefTrx.category} (Rp ${initialRefTrx.amount.toLocaleString('id-ID')})`);
      setRefTrxId(initialRefTrx.id);
      // Default assign to someone other than myself
      const other = availablePics.find(p => !isPicUtama(p.nama));
      if (other) {
        setAssignedToPic(other.nama);
      }
    }
  }, [initialRefTrx, isUtama, availablePics]);

  const resetForm = () => {
    setEditingTaskId(null);
    setTaskTitle('');
    setTaskDetail('');
    const other = availablePics.find(p => !isPicUtama(p.nama));
    setAssignedToPic(other ? other.nama : 'PIC 2 - Abil');
    setPriority('urgent');
    setDeadline('');
    setRefTrxSummary('');
    setRefTrxId('');
  };

  const handleOpenEdit = (task: TaskNote) => {
    if (!isUtama) return;
    setEditingTaskId(task.id);
    setTaskTitle(task.title);
    setTaskDetail(task.detail || '');
    setAssignedToPic(task.assignedToPic);
    setPriority(task.priority);
    setDeadline(task.deadline || '');
    setRefTrxSummary(task.transactionRefSummary || '');
    setRefTrxId(task.transactionRefId || '');
    setActiveTab('create');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isUtama) return;
    if (!taskTitle.trim() || !assignedToPic) return;

    setIsSubmitting(true);
    try {
      if (editingTaskId) {
        await onUpdateTask(editingTaskId, {
          title: taskTitle.trim(),
          detail: taskDetail.trim(),
          assignedToPic,
          priority,
          deadline: deadline || undefined,
          transactionRefSummary: refTrxSummary || undefined,
          transactionRefId: refTrxId || undefined
        });
      } else {
        await onCreateTask({
          title: taskTitle.trim(),
          detail: taskDetail.trim(),
          assignedByPic: currentPic.nama,
          assignedToPic,
          priority,
          deadline: deadline || undefined,
          transactionRefSummary: refTrxSummary || undefined,
          transactionRefId: refTrxId || undefined
        });
      }
      resetForm();
      setActiveTab('list');
    } catch (err) {
      console.error('Failed to submit task:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle sending reply from PIC 2 dst to PIC 1
  const handleSendReply = async (taskId: string, textOverride?: string) => {
    const textToSend = textOverride || (replyDrafts[taskId] || '').trim();
    if (!textToSend) return;

    setReplyingTaskId(taskId);
    try {
      await onAddReply(taskId, textToSend, currentPic.nama, currentPic.role);
      // clear draft
      setReplyDrafts(prev => ({ ...prev, [taskId]: '' }));
    } catch (err) {
      console.error('Failed to send reply:', err);
    } finally {
      setReplyingTaskId(null);
    }
  };

  // Filter tasks based on filterScope
  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      if (filterScope === 'to_me') {
        return task.assignedToPic === currentPic.nama;
      }
      if (filterScope === 'by_me') {
        return task.assignedByPic === currentPic.nama;
      }
      if (filterScope === 'pending') {
        return task.status === 'pending' || task.status === 'in_progress';
      }
      if (filterScope === 'completed') {
        return task.status === 'completed';
      }
      return true; // 'all'
    });
  }, [tasks, filterScope, currentPic.nama]);

  // Count pending for current active PIC
  const pendingForMeCount = useMemo(() => {
    return tasks.filter(t => t.assignedToPic === currentPic.nama && t.status !== 'completed').length;
  }, [tasks, currentPic.nama]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-xs transition-opacity animate-in fade-in duration-200">
      
      {/* Drawer Container */}
      <div className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-white shadow-xs ${
              isUtama ? 'bg-emerald-600' : 'bg-blue-600'
            }`}>
              {isUtama ? <Crown className="w-5 h-5 text-amber-300" /> : <FileText className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-base leading-tight">
                  Perintah Penugasan PIC
                </h3>
                {isUtama ? (
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-md flex items-center gap-1">
                    <Crown className="w-3 h-3 text-amber-600" />
                    <span>PIC 1 (Utama)</span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 rounded-md">
                    PIC Penerima Tugas
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {isUtama 
                  ? 'PIC 1 berwenang penuh memberi tugas & memantau balasan PIC 2 dst.'
                  : 'Kirim balasan teks laporan atas perintah tugas ke PIC 1 (Kiki).'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              resetForm();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition"
            title="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Bar: List vs Create (Create only available for PIC 1) */}
        <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                setActiveTab('list');
                resetForm();
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
                activeTab === 'list'
                  ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daftar Penugasan ({tasks.length})
            </button>

            {/* ONLY PIC 1 (Utama) CAN CREATE NEW ASSIGNMENT ORDERS */}
            {isUtama ? (
              <button
                onClick={() => {
                  resetForm();
                  setActiveTab('create');
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition flex items-center gap-1.5 ${
                  activeTab === 'create'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{editingTaskId ? 'Edit Penugasan' : '+ Beri Perintah Baru'}</span>
              </button>
            ) : (
              <span className="text-[11px] text-slate-500 italic hidden sm:inline px-2">
                (Hanya PIC 1 yg memberi tugas · Anda membalas via teks)
              </span>
            )}
          </div>

          <div className="text-[11px] text-slate-600 font-medium hidden sm:block">
            Petugas Aktif: <strong className="text-slate-900">{currentPic.nama}</strong>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto bg-white p-4">
          
          {/* TAB 1: LIST OF TASKS & DIALOGUE THREADS */}
          {activeTab === 'list' && (
            <div className="space-y-4">
              
              {/* Informative Role Banner */}
              <div className={`p-3 rounded-xl border text-xs leading-relaxed flex items-start gap-2.5 ${
                isUtama 
                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                  : 'bg-blue-50/70 border-blue-200 text-blue-950'
              }`}>
                {isUtama ? (
                  <Crown className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <MessageCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                )}
                <div>
                  {isUtama ? (
                    <span>
                      <strong>Mode Koordinator PIC 1 (Kiki):</strong> Berikan perintah tugas ke PIC 2, Nabila, PIC 3, dll. Balasan teks dari mereka akan langsung tampil di bawah setiap kartu tugas.
                    </span>
                  ) : (
                    <span>
                      <strong>Mode Petugas Pelaksana ({currentPic.nama}):</strong> Baca perintah penugasan dari PIC 1. Kirim balasan teks konfirmasi atau laporan progres langsung ke PIC 1 menggunakan kolom balasan di bawah tugas.
                    </span>
                  )}
                </div>
              </div>

              {/* Filter Tabs */}
              <div className="flex flex-wrap items-center gap-1.5 pb-2 border-b border-slate-100 text-xs">
                <button
                  onClick={() => setFilterScope('all')}
                  className={`px-2.5 py-1 rounded-md font-medium transition ${
                    filterScope === 'all'
                      ? 'bg-slate-800 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Semua ({tasks.length})
                </button>
                <button
                  onClick={() => setFilterScope('to_me')}
                  className={`px-2.5 py-1 rounded-md font-medium transition ${
                    filterScope === 'to_me'
                      ? 'bg-emerald-100 text-emerald-900 font-bold border border-emerald-300'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Ditugaskan ke Saya ({tasks.filter(t => t.assignedToPic === currentPic.nama).length})
                </button>
                {isUtama && (
                  <button
                    onClick={() => setFilterScope('by_me')}
                    className={`px-2.5 py-1 rounded-md font-medium transition ${
                      filterScope === 'by_me'
                        ? 'bg-emerald-100 text-emerald-900 font-bold border border-emerald-300'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Diberikan Saya ({tasks.filter(t => t.assignedByPic === currentPic.nama).length})
                  </button>
                )}
                <button
                  onClick={() => setFilterScope('pending')}
                  className={`px-2.5 py-1 rounded-md font-medium transition ${
                    filterScope === 'pending'
                      ? 'bg-amber-100 text-amber-900 font-bold border border-amber-300'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Pending ({tasks.filter(t => t.status !== 'completed').length})
                </button>
                <button
                  onClick={() => setFilterScope('completed')}
                  className={`px-2.5 py-1 rounded-md font-medium transition ${
                    filterScope === 'completed'
                      ? 'bg-slate-200 text-slate-900 font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Selesai ({tasks.filter(t => t.status === 'completed').length})
                </button>
              </div>

              {/* Tasks List */}
              {filteredTasks.length === 0 ? (
                <div className="py-16 text-center text-slate-400">
                  <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-200 text-slate-400 flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-6 h-6 text-slate-400" />
                  </div>
                  <h4 className="font-bold text-slate-800 text-sm">Tidak Ada Note Penugasan</h4>
                  <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                    {isUtama 
                      ? 'Belum ada tugas pada kategori ini. Klik "+ Beri Perintah Baru" untuk menugaskan PIC 2, Nabila, dll.'
                      : 'Belum ada penugasan untuk Anda saat ini.'}
                  </p>
                  {isUtama && (
                    <button
                      onClick={() => {
                        resetForm();
                        setActiveTab('create');
                      }}
                      className="mt-4 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg inline-flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Buat Perintah Penugasan Baru</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredTasks.map((task) => {
                    const isCompleted = task.status === 'completed';
                    const isToMe = task.assignedToPic === currentPic.nama;
                    const repliesCount = task.replies?.length || 0;

                    return (
                      <div
                        key={task.id}
                        className={`p-4 rounded-xl border transition-all ${
                          isCompleted
                            ? 'bg-slate-50/70 border-slate-200 opacity-80'
                            : task.priority === 'urgent'
                            ? 'bg-white border-rose-200 shadow-xs ring-1 ring-rose-100'
                            : 'bg-white border-slate-200 shadow-xs'
                        }`}
                      >
                        {/* Top Meta: Priority, Deadline, Status & Action (Edit/Delete only for PIC 1) */}
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {/* Priority Badge */}
                            {task.priority === 'urgent' ? (
                              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-rose-100 text-rose-800 rounded border border-rose-200 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3 text-rose-600" />
                                <span>Urgent</span>
                              </span>
                            ) : task.priority === 'normal' ? (
                              <span className="px-2 py-0.5 text-[10px] font-semibold bg-slate-100 text-slate-700 rounded border border-slate-200">
                                Normal
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 text-[10px] font-semibold bg-slate-50 text-slate-500 rounded border border-slate-200">
                                Rendah
                              </span>
                            )}

                            {/* Status Indicator */}
                            {isCompleted ? (
                              <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded flex items-center gap-1">
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span>Selesai</span>
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200 rounded flex items-center gap-1">
                                <Clock className="w-3 h-3 text-amber-600" />
                                <span>Menunggu Tindakan</span>
                              </span>
                            )}

                            {/* Deadline */}
                            {task.deadline && (
                              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-slate-400" />
                                <span>Batas: {task.deadline}</span>
                              </span>
                            )}
                          </div>

                          {/* Quick Edit & Delete (Only PIC 1 has authority) */}
                          {isUtama && (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleOpenEdit(task)}
                                className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition"
                                title="Edit Perintah Penugasan"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => setDeleteConfirmId(task.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                                title="Hapus Penugasan"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Title & Instructions */}
                        <div className="flex items-start gap-2.5">
                          <button
                            type="button"
                            onClick={() => onToggleStatus(task.id, isCompleted ? 'pending' : 'completed')}
                            className="mt-0.5 shrink-0 text-slate-400 hover:text-emerald-600 transition"
                            title={isCompleted ? 'Tandai belum selesai' : 'Tandai sudah selesai dikerjakan'}
                          >
                            {isCompleted ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-50" />
                            ) : (
                              <Circle className="w-5 h-5 text-slate-300 hover:text-emerald-500" />
                            )}
                          </button>

                          <div className="flex-1">
                            <h4 className={`text-sm font-bold text-slate-900 leading-snug ${isCompleted ? 'line-through text-slate-500' : ''}`}>
                              {task.title}
                            </h4>

                            {task.detail && (
                              <p className="text-xs text-slate-600 mt-1 leading-relaxed whitespace-pre-wrap">
                                {task.detail}
                              </p>
                            )}

                            {/* Transaction Reference Note */}
                            {task.transactionRefSummary && (
                              <div className="mt-2 text-[11px] bg-slate-50 border border-slate-200/80 rounded-lg p-2 text-slate-600 flex items-center gap-1.5">
                                <FileText className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                <span>Ref Jamaah: <strong>{task.transactionRefSummary}</strong></span>
                              </div>
                            )}

                            {/* Header metadata: Pemberi (PIC 1) & Penerima (PIC 2 dst) */}
                            <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[11px] text-slate-500">Pemberi Tugas:</span>
                                <span className="font-semibold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded text-[11px] flex items-center gap-1">
                                  <Crown className="w-3 h-3 text-amber-600" />
                                  <span>{task.assignedByPic}</span>
                                </span>
                                <ArrowRight className="w-3 h-3 text-slate-400" />
                                <span className="text-[11px] text-slate-500">Ditugaskan ke:</span>
                                <span className="font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded text-[11px]">
                                  {task.assignedToPic} {isToMe && '(Anda)'}
                                </span>
                              </div>

                              <div className="text-[10px] text-slate-400">
                                {new Date(task.createdAt).toLocaleString('id-ID', {
                                  day: 'numeric',
                                  month: 'short',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </div>
                            </div>

                            {/* ======================================================== */}
                            {/* THREAD BALASAN TEKS: PIC 2 DST KIRIM BALASAN KE PIC 1    */}
                            {/* ======================================================== */}
                            <div className="mt-3 pt-3 border-t border-slate-100 bg-slate-50/60 -mx-4 -mb-4 p-4 rounded-b-xl">
                              
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                                  <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                                  <span>Laporan & Balasan Teks ({repliesCount})</span>
                                </span>

                                <span className="text-[10px] text-slate-500">
                                  Tersampaikan langsung ke PIC 1
                                </span>
                              </div>

                              {/* Replies Stream / Feed */}
                              {repliesCount > 0 ? (
                                <div className="space-y-2 mb-3">
                                  {task.replies!.map((reply) => {
                                    const isFromPic1 = isPicUtama(reply.senderPic);
                                    const isMyReply = reply.senderPic === currentPic.nama;

                                    return (
                                      <div
                                        key={reply.id}
                                        className={`p-2.5 rounded-lg text-xs border ${
                                          isFromPic1
                                            ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                                            : isMyReply
                                            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950 ml-4'
                                            : 'bg-white border-slate-200 text-slate-800'
                                        }`}
                                      >
                                        <div className="flex items-center justify-between gap-2 mb-1">
                                          <div className="font-bold flex items-center gap-1">
                                            {isFromPic1 && <Crown className="w-3 h-3 text-amber-600" />}
                                            <span>{reply.senderPic}</span>
                                            {reply.senderRole && (
                                              <span className="text-[10px] text-slate-500 font-normal">
                                                · {reply.senderRole}
                                              </span>
                                            )}
                                          </div>
                                          <span className="text-[10px] text-slate-400">
                                            {new Date(reply.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                                          </span>
                                        </div>
                                        <p className="leading-relaxed whitespace-pre-wrap font-medium">
                                          {reply.text}
                                        </p>
                                      </div>
                                    );
                                  })}
                                </div>
                              ) : (
                                <p className="text-[11px] text-slate-400 italic mb-3">
                                  Belum ada balasan teks dari PIC penerima.
                                </p>
                              )}

                              {/* Form Balasan Teks (Bisa digunakan PIC 2 dst untuk lapor ke PIC 1, atau PIC 1 untuk tanggapan) */}
                              <div className="space-y-2">
                                
                                {/* Quick Reply Chips for 1-click response */}
                                <div className="flex flex-wrap items-center gap-1">
                                  <span className="text-[10px] text-slate-500 mr-1">Pilih Cepat:</span>
                                  {[
                                    '(menerima) baik kak',
                                    'Sedang diinput kak',
                                    'Sudah selesai diinput kak',
                                    'Siap, mutasi sudah diverifikasi'
                                  ].map((chip) => (
                                    <button
                                      key={chip}
                                      type="button"
                                      onClick={() => handleSendReply(task.id, chip)}
                                      disabled={replyingTaskId === task.id}
                                      className="px-2 py-0.5 bg-white hover:bg-emerald-50 active:bg-emerald-100 text-slate-700 hover:text-emerald-800 border border-slate-200 hover:border-emerald-300 rounded text-[10px] font-medium transition"
                                    >
                                      {chip}
                                    </button>
                                  ))}
                                </div>

                                {/* Custom Text Input Box */}
                                <div className="flex items-center gap-2">
                                  <input
                                    type="text"
                                    value={replyDrafts[task.id] || ''}
                                    onChange={(e) => setReplyDrafts(prev => ({ ...prev, [task.id]: e.target.value }))}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter' && !e.shiftKey) {
                                        e.preventDefault();
                                        handleSendReply(task.id);
                                      }
                                    }}
                                    placeholder={
                                      isUtama
                                        ? "Kirim instruksi tambahan ke penerima tugas..."
                                        : "Tulis balasan teks ke PIC 1 (Kiki) lalu tekan Kirim..."
                                    }
                                    className="flex-1 px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
                                  />
                                  <button
                                    type="button"
                                    disabled={replyingTaskId === task.id || !(replyDrafts[task.id] || '').trim()}
                                    onClick={() => handleSendReply(task.id)}
                                    className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50 shadow-xs shrink-0"
                                    title="Kirim Balasan Teks"
                                  >
                                    <Send className="w-3.5 h-3.5" />
                                    <span>{replyingTaskId === task.id ? 'Mengirim...' : 'Kirim Balasan'}</span>
                                  </button>
                                </div>

                              </div>

                            </div>

                          </div>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}

            </div>
          )}

          {/* TAB 2: CREATE / EDIT TASK FORM (ONLY ACCESSIBLE BY PIC 1 UTAMA) */}
          {activeTab === 'create' && (
            <div>
              {!isUtama ? (
                <div className="p-6 text-center bg-amber-50 border border-amber-200 rounded-2xl">
                  <ShieldAlert className="w-10 h-10 text-amber-600 mx-auto mb-2" />
                  <h4 className="font-bold text-slate-900 text-sm">Wewenang Khusus PIC 1 (Utama)</h4>
                  <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto">
                    Hanya <strong>PIC 1 - Kiki</strong> yang berwenang memberikan perintah penugasan baru. Anda dapat membalas dan melaporkan penugasan melalui tab <em>Daftar Penugasan</em>.
                  </p>
                  <button
                    onClick={() => setActiveTab('list')}
                    className="mt-4 px-4 py-2 bg-slate-800 text-white text-xs font-semibold rounded-lg"
                  >
                    Kembali ke Daftar Tugas
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  
                  <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-900 flex items-start gap-2">
                    <Crown className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong>PIC 1 (Utama) - Perintah Penugasan:</strong> Berikan instruksi ke PIC 2, Nabila, dll. Contoh: <em>"Tolong input cashflow jamaah Lintang (DP 1)"</em>. Mereka akan menerima notifikasi dan mengirimkan balasan teks ke Anda.
                    </div>
                  </div>

                  {/* Title / Perintah Penugasan */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      Perintah Penugasan <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={taskTitle}
                      onChange={(e) => setTaskTitle(e.target.value)}
                      placeholder="Contoh: Tolong input cashflow DP 1 jamaah Lintang"
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
                    />
                  </div>

                  {/* Detail Instruksi Tambahan */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      Detail Instruksi Tambahan (Opsional)
                    </label>
                    <textarea
                      rows={3}
                      value={taskDetail}
                      onChange={(e) => setTaskDetail(e.target.value)}
                      placeholder="Cth: Bukti transfer Bank BSI sudah masuk, mohon segera dicatat dan verifikasi kwitansi..."
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
                    />
                  </div>

                  {/* Assigned To PIC */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        Tugaskan Kepada (Penerima Tugas) <span className="text-rose-500">*</span>
                      </label>
                      <select
                        value={assignedToPic}
                        onChange={(e) => setAssignedToPic(e.target.value)}
                        required
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900 font-semibold"
                      >
                        {availablePics
                          .filter(pic => !isPicUtama(pic.nama))
                          .map((pic) => (
                            <option key={pic.id} value={pic.nama}>
                              {pic.nama} ({pic.role})
                            </option>
                          ))}
                      </select>
                    </div>

                    {/* Priority */}
                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        Tingkat Prioritas
                      </label>
                      <select
                        value={priority}
                        onChange={(e) => setPriority(e.target.value as TaskPriority)}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900 font-semibold"
                      >
                        <option value="urgent">🔴 Urgent / Penting</option>
                        <option value="normal">🟢 Normal</option>
                        <option value="low">⚪ Rendah</option>
                      </select>
                    </div>
                  </div>

                  {/* Deadline & Transaksi Terkait */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        Target Batas Waktu (Deadline)
                      </label>
                      <input
                        type="date"
                        value={deadline}
                        onChange={(e) => setDeadline(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-1">
                        Referensi Jamaah / Transaksi (Opsional)
                      </label>
                      <input
                        type="text"
                        value={refTrxSummary}
                        onChange={(e) => setRefTrxSummary(e.target.value)}
                        placeholder="Cth: Lintang Pramesti (DP 1)"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 text-slate-900"
                      />
                    </div>
                  </div>

                  {/* PIC Pemberi Tugas info */}
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                    <span className="text-slate-500">Pemberi Perintah:</span>
                    <span className="font-bold text-slate-900 flex items-center gap-1">
                      <Crown className="w-3.5 h-3.5 text-amber-600" />
                      <span>{currentPic.nama} ({currentPic.role})</span>
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        resetForm();
                        setActiveTab('list');
                      }}
                      className="flex-1 py-2.5 px-4 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-1 py-2.5 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{editingTaskId ? 'Simpan Perubahan' : 'Kirim Perintah Penugasan'}</span>
                    </button>
                  </div>

                </form>
              )}
            </div>
          )}

        </div>

        {/* Delete Confirmation Modal */}
        {deleteConfirmId && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
            <div className="w-full max-w-sm bg-white border border-slate-200 rounded-2xl shadow-xl p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-3">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Hapus Catatan Penugasan?</h4>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                Catatan penugasan ini akan dihapus permanen.
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 py-2 px-3 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await onDeleteTask(deleteConfirmId);
                    setDeleteConfirmId(null);
                  }}
                  className="flex-1 py-2 px-3 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg"
                >
                  Ya, Hapus
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
