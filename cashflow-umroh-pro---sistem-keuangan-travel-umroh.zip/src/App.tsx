import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Minus, 
  FileSpreadsheet, 
  Search, 
  Users, 
  ShieldCheck, 
  Sparkles,
  Plane,
  ClipboardList,
  CheckCircle2,
  Bell
} from 'lucide-react';
import Header from './components/Header';
import SummaryCards from './components/SummaryCards';
import TransactionTable from './components/TransactionTable';
import TransactionModal from './components/TransactionModal';
import TaskNoteDrawer from './components/TaskNoteDrawer';
import ExcelExportModal from './components/ExcelExportModal';
import LoginModal from './components/LoginModal';
import { Transaction, PicUser, TaskNote, TaskStatus, isPicUtama } from './types';
import { 
  fetchTransactions, 
  createTransaction, 
  updateTransaction, 
  deleteTransaction, 
  fetchPics, 
  registerPic, 
  updatePicUser,
  getCurrentUser, 
  logoutUser, 
  subscribeSseEvents,
  fetchTaskNotes,
  createTaskNote,
  updateTaskNote,
  updateTaskStatus,
  deleteTaskNote,
  addTaskReply
} from './services/api';
import { INITIAL_PICS, INITIAL_TASKS } from './mockData';

export default function App() {
  // Current user PIC
  const [currentUser, setCurrentUser] = useState<PicUser | null>(() => getCurrentUser());
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(!currentUser);

  // Available PICs
  const [pics, setPics] = useState<PicUser[]>(INITIAL_PICS);

  // Transactions State
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loadingTransactions, setLoadingTransactions] = useState(true);

  // Task Notes / Perintah Penugasan State
  const [tasks, setTasks] = useState<TaskNote[]>(INITIAL_TASKS);
  const [isTaskDrawerOpen, setIsTaskDrawerOpen] = useState(false);
  const [taskRefTrx, setTaskRefTrx] = useState<Transaction | null>(null);

  // Active Filter from Summary Cards
  const [activeFilter, setActiveFilter] = useState<string>('all');

  // Modals state
  const [isTrxModalOpen, setIsTrxModalOpen] = useState(false);
  const [trxModalType, setTrxModalType] = useState<'income' | 'expense'>('income');
  const [trxModalStage, setTrxModalStage] = useState<string>('dp1');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);

  // Load Initial Data
  const loadInitialData = async () => {
    try {
      const [fetchedTrx, fetchedPics, fetchedTasks] = await Promise.all([
        fetchTransactions(),
        fetchPics(),
        fetchTaskNotes()
      ]);
      setTransactions(fetchedTrx);
      if (fetchedPics && fetchedPics.length > 0) {
        setPics(fetchedPics);
      }
      if (fetchedTasks) {
        setTasks(fetchedTasks);
      }
    } catch (e) {
      console.error('Failed to load initial data:', e);
    } finally {
      setLoadingTransactions(false);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  // Subscribe to Realtime Server-Sent Events (SSE) for Multi-User Sync
  useEffect(() => {
    if (!currentUser) return;

    const unsubscribe = subscribeSseEvents(
      currentUser.nama,
      (eventData) => {
        // Transaction updated by another PIC in real time
        if (eventData.action === 'create' && eventData.transaction) {
          setTransactions(prev => {
            if (prev.some(t => t.id === eventData.transaction.id)) {
              return prev;
            }
            return [eventData.transaction, ...prev];
          });
        } else if (eventData.action === 'update' && eventData.transaction) {
          setTransactions(prev => prev.map(t => t.id === eventData.transaction.id ? eventData.transaction : t));
        } else if (eventData.action === 'delete' && eventData.transaction) {
          setTransactions(prev => prev.filter(t => t.id !== eventData.transaction.id));
        }
      },
      (action, task) => {
        // Task Note updated / assigned in real time
        if (action === 'create' && task) {
          setTasks(prev => {
            if (prev.some(t => t.id === task.id)) return prev;
            return [task, ...prev];
          });
        } else if ((action === 'update' || action === 'status') && task) {
          setTasks(prev => prev.map(t => t.id === task.id ? task : t));
        } else if (action === 'delete' && task) {
          setTasks(prev => prev.filter(t => t.id !== task.id));
        }
      }
    );

    return () => {
      unsubscribe();
    };
  }, [currentUser]);

  // Handle Login
  const handleLoginSuccess = (user: PicUser) => {
    setCurrentUser(user);
    setIsLoginModalOpen(false);
  };

  // Handle Logout
  const handleLogout = () => {
    logoutUser();
    setCurrentUser(null);
    setIsLoginModalOpen(true);
  };

  // Handle Switch PIC
  const handleSwitchPic = (pic: PicUser) => {
    setCurrentUser(pic);
    localStorage.setItem('cashflow_umroh_session', JSON.stringify(pic));
  };

  // Open transaction modal
  const handleOpenTransactionModal = (type: 'income' | 'expense', stage: string = 'dp1') => {
    setEditingTransaction(null);
    setTrxModalType(type);
    setTrxModalStage(stage);
    setIsTrxModalOpen(true);
  };

  // Edit transaction
  const handleEditTransaction = (trx: Transaction) => {
    setEditingTransaction(trx);
    setTrxModalType(trx.type);
    setTrxModalStage(trx.stage);
    setIsTrxModalOpen(true);
  };

  // Save transaction (Create or Update)
  const handleSaveTransaction = async (data: Omit<Transaction, 'id' | 'createdAt'>) => {
    if (!currentUser) return;

    if (editingTransaction) {
      const updated = await updateTransaction(editingTransaction.id, data, currentUser.nama);
      setTransactions(prev => prev.map(t => t.id === updated.id ? updated : t));
    } else {
      const created = await createTransaction(data);
      setTransactions(prev => {
        if (prev.some(t => t.id === created.id)) {
          return prev;
        }
        return [created, ...prev];
      });
    }
  };

  // Delete transaction
  const handleDeleteTransaction = async (id: string) => {
    await deleteTransaction(id);
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  // Update / Rename PIC (for PIC 3, 4, 5 manual editing)
  const handleUpdatePicName = async (picId: string, newName: string) => {
    try {
      const updated = await updatePicUser(picId, newName);
      setPics(prev => prev.map(p => p.id === picId ? updated : p));
      if (currentUser && currentUser.id === picId) {
        setCurrentUser(updated);
        localStorage.setItem('cashflow_umroh_session', JSON.stringify(updated));
      }
    } catch (e) {
      console.error('Failed to update PIC name:', e);
    }
  };

  // Task Note Handlers
  const handleCreateTask = async (data: Omit<TaskNote, 'id' | 'createdAt' | 'status'>) => {
    const created = await createTaskNote(data);
    setTasks(prev => {
      if (prev.some(t => t.id === created.id)) return prev;
      return [created, ...prev];
    });
  };

  const handleUpdateTask = async (id: string, updates: Partial<TaskNote>) => {
    const updated = await updateTaskNote(id, updates);
    setTasks(prev => prev.map(t => t.id === id ? updated : t));
  };

  const handleToggleTaskStatus = async (id: string, newStatus: TaskStatus) => {
    const updated = await updateTaskStatus(id, newStatus);
    setTasks(prev => prev.map(t => t.id === id ? updated : t));
  };

  const handleDeleteTask = async (id: string) => {
    await deleteTaskNote(id);
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  // Add text reply from PIC 2 dst to PIC 1
  const handleAddReply = async (taskId: string, text: string, senderPic: string, senderRole?: string) => {
    const updated = await addTaskReply(taskId, text, senderPic, senderRole);
    setTasks(prev => prev.map(t => t.id === taskId ? updated : t));
  };

  // Open Task Drawer with context from transaction
  const handleOpenTaskWithRef = (targetPicName: string, refTrx?: Transaction) => {
    setTaskRefTrx(refTrx || null);
    setIsTaskDrawerOpen(true);
  };

  // Default fallback user while modal is open (PIC 1 - Kiki)
  const activeUser = currentUser || {
    id: 'pic-1',
    username: 'Kiki',
    nama: 'PIC 1 - Kiki',
    role: 'PIC 1 (Utama) - Koordinator & Pemberi Tugas',
    avatarColor: 'bg-emerald-600',
    online: true,
    lastActive: 'Baru saja'
  };

  // Count of pending tasks specifically assigned to current active PIC
  const pendingTasksForMe = useMemo(() => {
    if (isPicUtama(activeUser)) {
      // For PIC 1: count all pending tasks in the system
      return tasks.filter(t => t.status !== 'completed').length;
    }
    return tasks.filter(t => t.assignedToPic === activeUser.nama && t.status !== 'completed').length;
  }, [tasks, activeUser]);

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* Login Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onLoginSuccess={handleLoginSuccess}
        availablePics={pics}
      />

      {/* Main Top Header */}
      <Header
        currentPic={activeUser}
        availablePics={pics}
        onSwitchPic={handleSwitchPic}
        onLogout={handleLogout}
        onOpenTransactionModal={handleOpenTransactionModal}
        onOpenExcelModal={() => setIsExcelModalOpen(true)}
        onUpdatePicName={handleUpdatePicName}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Banner Quick Action Bar & Multi-user notice */}
        <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Dashboard Kas & Keuangan Umroh
            </h1>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-2">
              <span>Alur: DP 1 &rarr; DP 2 &rarr; DP 3 &rarr; Pelunasan Jamaah & Land Arrangement</span>
              <span className="hidden md:inline">·</span>
              <span className="hidden md:inline-flex items-center gap-1 text-emerald-700 font-medium">
                <ShieldCheck className="w-3.5 h-3.5" /> Multi-User Real-time (&gt;5 PIC Aktif)
              </span>
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => handleOpenTransactionModal('income', 'dp1')}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>+ Input Kas Masuk</span>
            </button>
            <button
              onClick={() => handleOpenTransactionModal('expense')}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-semibold text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-2"
            >
              <Minus className="w-4 h-4" />
              <span>- Input Kas Keluar</span>
            </button>
          </div>
        </div>

        {/* 4 Summary Cards */}
        <SummaryCards
          transactions={transactions}
          activeFilter={activeFilter}
          onQuickFilter={(type) => setActiveFilter(prev => prev === type ? 'all' : type)}
        />

        {/* Main High-Density Transaction Table with Passport Search */}
        <div className="mb-12">
          <TransactionTable
            transactions={transactions}
            onEdit={handleEditTransaction}
            onDelete={handleDeleteTransaction}
            currentPic={activeUser}
            availablePics={pics}
            onAssignTask={handleOpenTaskWithRef}
          />
        </div>

      </main>

      {/* Floating Note Penugasan PIC Button in Bottom Right */}
      <div className="fixed bottom-5 right-5 z-40">
        <button
          onClick={() => {
            setTaskRefTrx(null);
            setIsTaskDrawerOpen(true);
          }}
          className="relative flex items-center gap-2 px-4 py-3 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-0.5 border border-emerald-600"
          title="Buka Note Perintah Penugasan PIC"
        >
          <ClipboardList className="w-5 h-5" />
          <span className="text-xs font-bold tracking-wide">
            Note Penugasan PIC
          </span>

          {pendingTasksForMe > 0 && (
            <span className="ml-1 px-2 py-0.5 bg-rose-500 text-white text-[11px] font-extrabold rounded-full border-2 border-white shadow-xs animate-bounce">
              {pendingTasksForMe}
            </span>
          )}
        </button>
      </div>

      {/* Transaction Modal (Input Flow: Jamaah -> Agen -> Tgl Brgkt -> Pindah Tgl -> DP 1 -> DP 2 -> DP 3 -> Pelunasan -> Edit/Hapus) */}
      <TransactionModal
        isOpen={isTrxModalOpen}
        onClose={() => setIsTrxModalOpen(false)}
        onSave={handleSaveTransaction}
        initialData={editingTransaction}
        defaultType={trxModalType}
        defaultStage={trxModalStage}
        currentPic={activeUser}
        availablePics={pics}
      />

      {/* Excel Export Modal (Daily & Monthly XLSX Reports) */}
      <ExcelExportModal
        isOpen={isExcelModalOpen}
        onClose={() => setIsExcelModalOpen(false)}
        transactions={transactions}
        currentPic={activeUser}
      />

      {/* Task Note / Perintah Penugasan Drawer */}
      <TaskNoteDrawer
        isOpen={isTaskDrawerOpen}
        onClose={() => {
          setIsTaskDrawerOpen(false);
          setTaskRefTrx(null);
        }}
        currentPic={activeUser}
        availablePics={pics}
        tasks={tasks}
        onCreateTask={handleCreateTask}
        onUpdateTask={handleUpdateTask}
        onToggleStatus={handleToggleTaskStatus}
        onDeleteTask={handleDeleteTask}
        onAddReply={handleAddReply}
        initialRefTrx={taskRefTrx}
      />

      {/* Clean Minimalist Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 px-6 text-center text-xs text-slate-400">
        <p>Cashflow Umroh Pro &copy; 2026 · Sistem Informasi Keuangan & Kas Travel Umroh Terintegrasi</p>
      </footer>

    </div>
  );
}
